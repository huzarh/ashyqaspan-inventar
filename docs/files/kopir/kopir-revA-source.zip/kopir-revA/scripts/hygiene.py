#!/usr/bin/env python3
# SPDX-License-Identifier: CERN-OHL-P-2.0
"""Main board hygiene (idempotent; tracks, pads and vias are untouched, the pours are refilled):
- D1 footprint type SMD (was through-hole, DRC error upstream);
- the two footprints that only existed embedded in the board (Espressif:ESP32-C3-MINI-1, Rust_Board:SOD-882) exported
  to the project libraries and registered in the project footprint table; the two esp-rs logo footprints, unused
  since the rebranding, removed from the project library (CERN-OHL-P 7.2);
- back silkscreen: attribution lines moved clear of the 'IO9/BOOT' pin label; the I2C info block marks the
  temperature/humidity sensor as optional (U1 SHTC3 is not fitted in rev A); the workshop-site URL lines removed
  (they did not lead to the design files) and the JLC order-number marker (JLCPCB prints no order numbers since
  May 2026); our silkscreen lines raised to 1.0 mm;
- GND pours kept 0.3 mm from the routed edge and the mounting cut-outs and 0.25 mm from J1's unplated peg holes
  (JLCPCB), through zone-only DRC rules and a zone refill: tracks, pads and vias are untouched;
- schematic: leftover esp-rs logo image removed, LED note corrected (the red LED is on GPIO10), title block
  comments shortened so they fit the drawing sheet."""
import os
import re
import sys

import pcbnew

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ZONE_RULE = """(version 1)
# JLCPCB: keep copper pours 0.3 mm from the routed board edge and cut-outs and 0.25 mm from unplated holes
# (tracks, pads and vias are untouched)
(rule "pour_edge_clearance"
\t(condition "A.Type == 'Zone'")
\t(constraint edge_clearance (min 0.3mm)))
(rule "pour_hole_clearance"
\t(condition "A.Type == 'Zone'")
\t(constraint hole_clearance (min 0.25mm)))
"""
BIGGER = {'rev A · 2026-11-10': 82.0, 'ASHYQ ASPAN FOUNDATION': 83.5,          # our back-silkscreen lines: new y (mm)
          'Derived from Espressif': 116.75, 'ESP32-C3-DevKit-RUST-2': 118.4, 'CERN-OHL-P-2.0': 119.75}
COMMENTS = ['Derived from ESP32-C3-DevKit-RUST-2 rev 2.0 by Espressif Systems / esp-rs',
            'github.com/esp-rs/esp-rust-board - CERN-OHL-P-2.0, provided without warranty',
            'Modified 2026-11-10 by Ashyq Aspan Foundation: BOM, notices, rebranding (NOTICE.md)',
            'No track, pad or via changes. Drone I/O: Köpir Wing add-on']
BASE = os.path.join(ROOT, 'hardware', 'kopir-c3', 'kopir-c3')
LIBS = os.path.join(ROOT, 'kicad_libs')


def export(fp, lib_dir):
    os.makedirs(lib_dir, exist_ok=True)
    cp = pcbnew.FOOTPRINT(fp)                      # library copy: origin, 0 deg, front side, no board links
    cp.SetParent(None)
    if cp.GetLayer() != pcbnew.F_Cu:
        cp.Flip(cp.GetPosition(), pcbnew.FLIP_DIRECTION_LEFT_RIGHT)
    cp.SetOrientationDegrees(0)
    cp.SetPosition(pcbnew.VECTOR2I(0, 0))
    cp.SetPath(pcbnew.KIID_PATH())
    cp.SetReference('REF**')
    pcbnew.PCB_IO_KICAD_SEXPR().FootprintSave(lib_dir, cp)     # pcbnew.FootprintSave() cannot guess the type of a new .pretty
    return os.path.join(lib_dir, cp.GetFPID().GetLibItemName().wx_str() + '.kicad_mod')


def schematic():
    path = BASE + '.kicad_sch'
    s = open(path, encoding='utf-8').read()
    while '\n\t(image' in s:                       # esp-rs logo bitmap left on the sheet
        a = s.index('\n\t(image') + 1
        depth, k = 0, a
        while True:
            c = s[k]
            if c == '"':
                k += 1
                while s[k] != '"':
                    k += 2 if s[k] == '\\' else 1
            elif c == '(':
                depth += 1
            elif c == ')':
                depth -= 1
                if depth == 0:
                    break
            k += 1
        s = s[:a - 1] + s[k + 1:]
    s = s.replace('Regular on GPIO7', 'Regular on GPIO10')
    tb = s.index('\t(title_block')
    te = s.index('\n\t)', tb)
    body = re.sub(r'\n\t\t\(comment \d+ "[^"]*"\)', '', s[tb:te])
    body += ''.join('\n\t\t(comment %d "%s")' % (i + 1, c) for i, c in enumerate(COMMENTS))
    s = s[:tb] + body + s[te:]
    open(path, 'w', encoding='utf-8').write(s)


def enlarge(b):
    """Our silkscreen lines to JLC's 1.0 mm minimum height (0.15 mm stroke); characters narrowed where space is short."""
    MM, ToMM = pcbnew.FromMM, pcbnew.ToMM

    def box(bb, grow=0.0):
        return (ToMM(bb.GetX()) - grow, ToMM(bb.GetY()) - grow, ToMM(bb.GetRight()) + grow, ToMM(bb.GetBottom()) + grow)

    def ink(t, grow=0.0):
        """Printed extent of a text, including the box of knockout texts such as the pin labels."""
        poly = pcbnew.SHAPE_POLY_SET()
        t.TransformTextToPolySet(poly, 0, MM(0.005), pcbnew.ERROR_INSIDE)
        return box(poly.BBox(), grow)

    hit = lambda a, c: a[0] < c[2] and c[0] < a[2] and a[1] < c[3] and c[1] < a[3]
    texts = [d for d in b.GetDrawings() if d.GetClass() == 'PCB_TEXT' and d.GetLayer() == pcbnew.B_SilkS]
    obstacles = [box(p.GetBoundingBox()) for f in b.GetFootprints() for p in f.Pads() if p.IsOnLayer(pcbnew.B_Cu)]
    obstacles += [box(g.GetBoundingBox()) for f in b.GetFootprints() for g in f.GraphicalItems() if g.GetLayer() == pcbnew.B_SilkS]
    for t in texts:                                # (vias are tented: silkscreen may cross them, as upstream does)
        if t.GetText() in BIGGER:
            t.SetPosition(pcbnew.VECTOR2I(t.GetPosition().x, MM(BIGGER[t.GetText()])))
    obstacles += [box(f.Reference().GetBoundingBox()) for f in b.GetFootprints() if f.Reference().IsVisible() and f.Reference().GetLayer() == pcbnew.B_SilkS]
    edge = b.GetBoardEdgesBoundingBox()
    x0, x1 = ToMM(edge.GetX()) + 0.3, ToMM(edge.GetRight()) - 0.3
    for t in texts:
        if t.GetText() not in BIGGER:
            continue
        others = obstacles + [ink(o) for o in texts if o is not t]
        old = (t.GetTextWidth(), t.GetTextHeight(), t.GetTextThickness())
        for scale in (1.0, 0.95, 0.9, 0.85, 0.8, 0.75):
            t.SetTextSize(pcbnew.VECTOR2I(MM(scale), MM(1.0)))
            t.SetTextThickness(MM(0.15))
            bb = ink(t, 0.15)
            if bb[0] >= x0 and bb[2] <= x1 and not any(hit(bb, o) for o in others):
                print('silkscreen %r -> 1.0 mm (width %.2f)' % (t.GetText(), scale))
                break
        else:
            t.SetTextSize(pcbnew.VECTOR2I(old[0], old[1]))
            t.SetTextThickness(old[2])
            print('silkscreen %r kept at %.2f mm (no room for 1.0 mm)' % (t.GetText(), ToMM(old[1])))


def main():
    schematic()
    with open(BASE + '.kicad_dru', 'w') as f:      # must exist before the board is loaded (the zone filler reads it)
        f.write(ZONE_RULE)
    b = pcbnew.LoadBoard(BASE + '.kicad_pcb')
    d1 = b.FindFootprintByReference('D1')
    d1.SetAttributes((d1.GetAttributes() & ~pcbnew.FP_THROUGH_HOLE) | pcbnew.FP_SMD)
    for ref, lib in (('U3', 'Espressif.pretty'), ('D1', 'Rust_Board.pretty')):
        print('exported', export(b.FindFootprintByReference(ref), os.path.join(LIBS, lib)))
    for name in ('esp-rs_logo_4mm.kicad_mod', 'esp-rs_logo_tiny.kicad_mod'):
        path = os.path.join(LIBS, 'Rust_Board.pretty', name)
        if os.path.exists(path):
            os.remove(path)
            print('removed', path)
    lines = ('Derived from Espressif', 'ESP32-C3-DevKit-RUST-2', 'CERN-OHL-P-2.0')
    for d in b.GetDrawings():
        if d.GetClass() == 'PCB_TEXT' and d.GetLayer() == pcbnew.B_SilkS:
            if d.GetText() in lines:                 # clear of the 'IO9/BOOT' label and of battery pad U4.30
                d.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(147.6), d.GetPosition().y))
            elif d.GetText().startswith('I2C BUS\nIMU 0x68\n'):
                d.SetText(re.sub(r'\n\(?T\+H [^\n]*\n', '\nT+H opt.\n', d.GetText()))   # same width as 'T+H 0x70'
    tb = b.GetTitleBlock()
    for i in range(9):
        tb.SetComment(i, COMMENTS[i] if i < len(COMMENTS) else '')
    b.SetTitleBlock(tb)
    enlarge(b)
    gone = [d for d in b.GetDrawings() if d.GetClass() == 'PCB_TEXT'
            and d.GetText() in ('huzarh.github.io/', 'ashyqaspan-inventar', 'JLCJLCJLCJLC')]   # JLC prints no order numbers since 2026-05
    for d in gone:                                 # collected first: iterating after Remove() breaks the SWIG proxies
        b.Remove(d)
    b.BuildConnectivity()
    pcbnew.ZONE_FILLER(b).Fill(b.Zones())
    pcbnew.SaveBoard(BASE + '.kicad_pcb', b)
    table = os.path.join(os.path.dirname(BASE), 'fp-lib-table')
    t = open(table).read()
    if '"Espressif"' not in t:
        t = t.replace('\n)', '\n  (lib (name "Espressif")(type "KiCad")(uri "${KIPRJMOD}/../../kicad_libs/Espressif.pretty")(options "")'
                             '(descr "ESP32-C3-MINI-1 footprint as used on the board"))\n)')
        open(table, 'w').write(t)
    print(open(table).read())


if __name__ == '__main__':
    main()
