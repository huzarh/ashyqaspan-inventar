#!/usr/bin/env python3
# SPDX-License-Identifier: CERN-OHL-P-2.0
"""Release folder fab/release/, published as is (web folder of the workshop site). Run after scripts/jlc_export.py
for both boards and after scripts/renders.py, and commit first: the source zip is the committed tree.

    kopir-c3-revA-jlcpcb.zip     Gerber zip, JLC BOM + CPL + CPL report, schematic PDF, top/bottom renders, STEP model,
                                 summary.json, ORDERING.txt, README.md (with its image), NOTICE.md, LICENSE-CERN-OHL
    kopir-wing-revA-jlcpcb.zip   the same for the wing, plus the hand-soldered parts list
    kopir-revA-source.zip        all repository files at HEAD (KiCad projects, libraries, scripts, docs; no git history)
    SHA256SUMS                   checksums of the three zips
    index.html, README.md, NOTICE.md, LICENSE-CERN-OHL, kopir-renders.png   download page and loose copies

ORDERING.txt takes the board size, placement count and hand-soldered parts from fab/<board>/summary.json and repeats
the ordering rules of README.md. The ERC/DRC JSON reports and the loose Gerber folder stay out of the zips
(summary.json carries their counts). Every check runs before anything is written; the zips are written under
temporary names and only renamed when all of them are complete.
"""
import hashlib
import html
import json
import os
import re
import shutil
import subprocess
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FAB = os.path.join(ROOT, 'fab')
OUT = os.path.join(FAB, 'release')
REV = 'revA'

PCB_RULES = """PCB
  Upload {name}_gerbers.zip. 2 layers, 1.6 mm.
  The design specifies black solder mask, white silkscreen and ENIG. JLCPCB's Economic PCBA offers ENIG only
  with green mask (capabilities page, checked 2026-11-10), so choose one of:
    - black mask + lead-free HASL, Economic PCBA (the look as designed);
    - green mask + ENIG, Economic PCBA ({enig});
    - black mask + ENIG, Standard PCBA (needs a panel with rails and fiducials at this size; higher fees).
  Mark on PCB: leave the default. JLCPCB no longer prints order numbers (since May 2026); the board has no marker.
"""
BOARDS = {
    'kopir-c3': dict(
        title='Köpir C3 rev A - main board',
        enig='flattest pads for the LGA module and IMU',
        polarity='D2/D3/D9 (LEDs), D4/D6 (Schottky) and the USB-C connector J1. The red LEDs\' LCSC footprint\n'
                 '    (C2286) numbers the anode as pad 1, so its pin-1 dot sits opposite the KiCad cathode mark; this is correct.',
        # every schematic symbol that is DNP or not in the BOM, with the reason (checked against the schematic below)
        not_fitted={'U1': 'SHTC3 temperature/humidity sensor, optional',
                    'Y1': '32 kHz crystal: Y1, C12, C13 and R12 stay empty when the wing\'s AUX port uses GPIO0/GPIO1',
                    'C12': None, 'C13': None, 'R12': None,
                    'C14': '1 nF on BOOT, not fitted upstream either',
                    'TP2': 'test pad (IMU INT2)',
                    'U4': 'the header pads: hand-soldered male headers, see below'},
        hand="""Hand-soldered
  1x16 and 1x12 2.54 mm male headers in U4's pads, pins down: the plastic spacer on the bottom face
  (the face with the KÖPIR C3 name), soldered on the component side. Key: cut off pin 3 of the 16-pin
  row (third from the antenna end) and pins 17 and 18 (the two NC pins at the USB-C end of the 12-pin
  row). See README.md, "Assembly and mounting".
"""),
    'kopir-wing': dict(
        title='Köpir Wing rev A - add-on board',
        enig='same finish as Köpir C3',
        panel='  Order single boards; if JLCPCB panelizes, keep rails and tabs off the two JST edges.\n',
        polarity='D1 (TVS) and D2 (Schottky).',
        not_fitted={},
        hand="""Hand-soldered ({name}_not_assembled.csv: {parts})
  1x16 (J1) and 1x12 (J5) 2.54 mm female headers, bodies on the back (marked MAIN BOARD SIDE), soldered on the
  component side. Key: block J1 socket 3 and J5 sockets 1 and 2 (marked KEY). The wing mounts component side
  down under Köpir C3. See README.md, "Assembly and mounting".
"""),
}


def not_fitted(sch):
    """References of the schematic symbols that are DNP or excluded from the BOM (power symbols left out)."""
    refs = set()
    for body in re.findall(r'\n\t\(symbol\n\t\t\(lib_id "[^"]+"(.*?)\n\t\)', open(sch, encoding='utf-8').read(), re.S):
        ref = re.search(r'\(property "Reference" "([^"]+)"', body).group(1)
        if not ref.startswith('#') and re.search(r'\((?:dnp yes|in_bom no)\)', body):
            refs.add(ref)
    return refs


def ordering(board, name):
    spec = BOARDS[board]
    summary = json.load(open(os.path.join(FAB, board, 'summary.json')))
    w, h = summary['board_size_mm']
    refs = not_fitted(os.path.join(ROOT, 'hardware', board, board + '.kicad_sch'))
    if refs != set(spec['not_fitted']):
        raise SystemExit('%s: not-fitted parts in the schematic %s differ from release.py %s'
                         % (board, sorted(refs), sorted(spec['not_fitted'])))
    text = '%s - JLCPCB order (%.2f x %.2f mm)\n\n' % (spec['title'], w, h)
    text += PCB_RULES.format(name=name, enig=spec['enig']) + spec.get('panel', '') + '\n'
    text += ('Assembly\n  Top side only, %d placements. BOM = %s_bom_jlc.csv, CPL = %s_cpl_jlc.csv.\n'
             '  Rotations and centres in the CPL are already solved against each LCSC part\'s own footprint\n'
             '  (%s_cpl_report.json). In the JLC preview still check the polarity of:\n    %s\n'
             % (summary['cpl_parts'], name, name, name, spec['polarity']))
    if spec['not_fitted']:
        text += '  Not fitted (not in the BOM):\n'
        text += ''.join('    %-4s %s\n' % (ref, why) for ref, why in spec['not_fitted'].items() if why)
    text += '\n' + spec['hand'].format(name=name, parts=', '.join(summary['not_assembled']))
    return text


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


INDEX = """<!doctype html>
<html lang="kk">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Köpir C3 + Köpir Wing {rev} — файлдар / files</title>
<style>
body{{font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;max-width:900px;margin:2rem auto;padding:0 1rem;line-height:1.5;color:#1d1d1f}}
img{{max-width:100%;height:auto;border-radius:8px}}
table{{border-collapse:collapse;width:100%}}
td,th{{padding:.35rem .6rem;border-bottom:1px solid #ddd;text-align:left;vertical-align:top}}
.muted{{color:#555;font-size:.92em}}
</style>
</head>
<body>
<h1>Köpir C3 + Köpir Wing — {rev}</h1>
<p>Ұшу контроллеріне арналған ESP32-C3 көпір-платасы және дрон кіріс-шығысына арналған қосымша плата.
Ashyq Aspan Foundation.<br>
ESP32-C3 companion board for FPV / drone flight controllers, with a drone I/O add-on board.</p>
<img src="kopir-renders.png" alt="Köpir C3 and Köpir Wing, top and bottom">
<h2>Файлдар / Files</h2>
<table>
<tr><th>Файл / File</th><th>Мазмұны / Contents</th><th>Өлшемі / Size</th></tr>
{rows}
</table>
<p class="muted">Köpir C3 — Espressif Systems / esp-rs жасаған ESP32-C3-DevKit-RUST-2 rev 2.0 платасының туындысы
(<a href="https://github.com/esp-rs/esp-rust-board">github.com/esp-rs/esp-rust-board</a>), CERN-OHL-P-2.0.
Espressif пен esp-rs аттары тек шығу тегін көрсету үшін айтылады, олар бұл жобаны қолдамайды. Кепілдіксіз беріледі.<br>
Derived from ESP32-C3-DevKit-RUST-2 rev 2.0 by Espressif Systems / esp-rs, CERN-OHL-P-2.0. Espressif and esp-rs are
named only to describe the origin of the design and do not endorse this project. Provided without warranty.</p>
<p><a href="../../#/projects/kopir-c3-pcb">Жоба беті / Project page</a></p>
</body>
</html>
"""
FILES = [('kopir-c3-revA-jlcpcb.zip', 'Köpir C3: Gerber, BOM, CPL, схема PDF, STEP, ORDERING.txt'),
         ('kopir-wing-revA-jlcpcb.zip', 'Köpir Wing: Gerber, BOM, CPL, схема PDF, STEP, ORDERING.txt'),
         ('kopir-revA-source.zip', 'KiCad 9 жобалары, кітапханалар, скрипттер, құжаттар / KiCad 9 sources, libraries, '
                                   'scripts, docs (no git history)'),
         ('SHA256SUMS', 'бақылау сомалары / checksums'),
         ('README.md', 'сипаттама, құрастыру, тапсырыс / description, assembly, ordering'),
         ('NOTICE.md', 'шығу тегі және өзгерістер тізімі / origin and list of modifications'),
         ('LICENSE-CERN-OHL', 'CERN-OHL-P-2.0')]
LOOSE = ['README.md', 'NOTICE.md', 'LICENSE-CERN-OHL', 'art/kopir-renders.png']


def main():
    if subprocess.run(['git', '-C', ROOT, 'rev-parse', '--verify', 'HEAD'], capture_output=True).returncode:
        raise SystemExit('release.py needs the git repository (the source zip is git archive HEAD)')
    texts = {board: ordering(board, '%s-%s' % (board, REV)) for board in BOARDS}   # all checks before any file is written
    os.makedirs(OUT, exist_ok=True)
    sums = os.path.join(OUT, 'SHA256SUMS')
    if os.path.exists(sums):
        os.remove(sums)
    pending = []                                   # (temporary path, final path)
    try:
        for board, text in texts.items():
            src = os.path.join(FAB, board)
            name = '%s-%s' % (board, REV)
            files = sorted(f for f in os.listdir(src) if f.startswith(name) and not f.endswith(('_erc.json', '_drc.json')))
            files.append('summary.json')
            path = os.path.join(OUT, name + '-jlcpcb.zip')
            pending.append((path + '.tmp', path))
            with zipfile.ZipFile(path + '.tmp', 'w', zipfile.ZIP_DEFLATED) as z:
                for f in files:
                    z.write(os.path.join(src, f), name + '/' + f)
                z.writestr(name + '/ORDERING.txt', text)
                for f in LOOSE:
                    z.write(os.path.join(ROOT, f), name + '/' + f)
        path = os.path.join(OUT, 'kopir-%s-source.zip' % REV)
        pending.append((path + '.tmp', path))
        subprocess.run(['git', '-C', ROOT, 'archive', '--format=zip', '--prefix=kopir-%s/' % REV, '-o', path + '.tmp', 'HEAD'],
                       check=True)
    except BaseException:
        for tmp, _ in pending:
            if os.path.exists(tmp):
                os.remove(tmp)
        raise
    for tmp, path in pending:
        os.replace(tmp, path)
    made = [path for _, path in pending]
    with open(sums, 'w') as f:
        for p in made:
            f.write('%s  %s\n' % (sha(p), os.path.basename(p)))
    for f in LOOSE:
        shutil.copy(os.path.join(ROOT, f), OUT)
    size = lambda f: '%.0f kB' % (os.path.getsize(os.path.join(OUT, f)) / 1024)
    rows = '\n'.join('<tr><td><a href="%s">%s</a></td><td>%s</td><td>%s</td></tr>' % (f, f, html.escape(what), size(f))
                     for f, what in FILES)
    with open(os.path.join(OUT, 'index.html'), 'w', encoding='utf-8') as f:
        f.write(INDEX.format(rev='rev A', rows=rows))
    for p in made:
        print('%8.0f kB  %s' % (os.path.getsize(p) / 1024, p))


if __name__ == '__main__':
    main()
