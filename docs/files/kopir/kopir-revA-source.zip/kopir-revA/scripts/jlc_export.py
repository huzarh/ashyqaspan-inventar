#!/usr/bin/env python3
# SPDX-License-Identifier: CERN-OHL-P-2.0
"""JLCPCB fabrication + assembly package from a KiCad 9 project, using kicad-cli only (reproducible, headless).

    python3 jlc_export.py path/to/project.kicad_pro --out fab/ [--lcsc-field LCSC] [--name myboard-v1.0]

Outputs in --out:
  <name>_gerbers.zip        Gerbers (all copper, mask, paste, silk, edge) + Excellon drill (PTH/NPTH) + drill map
  <name>_bom_jlc.csv        Comment, Designator, Footprint, LCSC Part #   (grouped)
  <name>_cpl_jlc.csv        Designator, Mid X, Mid Y, Layer, Rotation     (mm, top/bottom)
  <name>_schematic.pdf, <name>_erc.json, <name>_drc.json, <name>_top.png, <name>_bottom.png, <name>.step (optional)
  summary.json              board size, layers, part counts, missing LCSC numbers, ERC/DRC counts by severity
With --cpl-fix the CPL is rebuilt by jlc_cpl_fix.py: rotation and centre of every placed part are solved against the
LCSC part's own (EasyEDA) footprint, pads paired by pin function, and the export fails on a footprint/pinout mismatch.
Without it, rotations are KiCad's (optionally shifted with --rot-offsets file.json) and must be checked on JLCPCB.
Parts without an LCSC number (hand-soldered headers, test points, board outlines) go to <name>_not_assembled.csv.
"""
import argparse
import csv
import glob
import json
import os
import re
import shutil
import subprocess
import sys
import zipfile


def run(cmd, check=True):
    p = subprocess.run(cmd, capture_output=True, text=True)
    if check and p.returncode not in (0, 5):          # kicad-cli returns 5 for "violations found" with --exit-code-violations
        sys.stderr.write(p.stdout + p.stderr)
        raise SystemExit('command failed: ' + ' '.join(cmd))
    return p


def root_schematic(pro):
    base = os.path.splitext(pro)[0]
    sch = base + '.kicad_sch'
    return sch if os.path.exists(sch) else None


def board_layers(pcb):
    import pcbnew
    b = pcbnew.LoadBoard(pcb)
    n_cu = b.GetCopperLayerCount()
    cu = ['F.Cu'] + ['In%d.Cu' % i for i in range(1, n_cu - 1)] + ['B.Cu']
    bb = b.GetBoardEdgesBoundingBox()
    stroke = max([d.GetWidth() for d in b.GetDrawings() if d.GetLayer() == pcbnew.Edge_Cuts] or [0])
    size = (pcbnew.ToMM(bb.GetWidth() - stroke), pcbnew.ToMM(bb.GetHeight() - stroke))   # outline centre lines
    fps = list(b.GetFootprints())
    smt_top = sum(1 for f in fps if not f.IsFlipped() and f.GetAttributes() & pcbnew.FP_SMD)
    smt_bot = sum(1 for f in fps if f.IsFlipped() and f.GetAttributes() & pcbnew.FP_SMD)
    tht = sum(1 for f in fps if f.GetAttributes() & pcbnew.FP_THROUGH_HOLE)
    return cu, size, dict(footprints=len(fps), smd_top=smt_top, smd_bottom=smt_bot, through_hole=tht)


def severity_counts(path, key):
    try:
        with open(path) as f:
            data = json.load(f)
    except (OSError, ValueError):
        return None
    counts = {}
    items = []
    if key == 'erc':
        for sheet in data.get('sheets', []):
            items += sheet.get('violations', [])
    else:
        items = data.get('violations', []) + data.get('unconnected_items', []) + data.get('schematic_parity', [])
    for v in items:
        s = v.get('severity', 'unknown')
        counts[s] = counts.get(s, 0) + 1
    types = {}
    for v in items:
        types[v.get('type', '?')] = types.get(v.get('type', '?'), 0) + 1
    return dict(by_severity=counts, by_type=dict(sorted(types.items(), key=lambda kv: -kv[1])))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('project')
    ap.add_argument('--out', required=True)
    ap.add_argument('--name')
    ap.add_argument('--lcsc-field', default='LCSC')
    ap.add_argument('--rot-offsets', help='JSON {footprint_regex: degrees} added to CPL rotation')
    ap.add_argument('--step', action='store_true')
    ap.add_argument('--cpl-fix', action='store_true', help='solve CPL rotation/centre against the LCSC footprints')
    a = ap.parse_args()
    pro = os.path.abspath(a.project)
    base = os.path.splitext(pro)[0]
    pcb = base + '.kicad_pcb'
    sch = root_schematic(pro)
    name = a.name or os.path.basename(base)
    out = os.path.abspath(a.out)
    os.makedirs(out, exist_ok=True)
    gdir = os.path.join(out, 'gerbers')
    shutil.rmtree(gdir, ignore_errors=True)
    os.makedirs(gdir)
    cu, size, fpcount = board_layers(pcb)
    layers = cu + ['F.Paste', 'B.Paste', 'F.Silkscreen', 'B.Silkscreen', 'F.Mask', 'B.Mask', 'Edge.Cuts']
    run(['kicad-cli', 'pcb', 'export', 'gerbers', '-o', gdir + '/', '-l', ','.join(layers), '--subtract-soldermask', pcb])
    run(['kicad-cli', 'pcb', 'export', 'drill', '-o', gdir + '/', '--format', 'excellon', '--excellon-units', 'mm',
         '--excellon-separate-th', '--generate-map', '--map-format', 'gerberx2', pcb])
    zpath = os.path.join(out, name + '_gerbers.zip')
    with zipfile.ZipFile(zpath, 'w', zipfile.ZIP_DEFLATED) as z:
        for f in sorted(os.listdir(gdir)):
            z.write(os.path.join(gdir, f), f)
    # placement
    pos_raw = os.path.join(out, 'pos_raw.csv')
    run(['kicad-cli', 'pcb', 'export', 'pos', '-o', pos_raw, '--format', 'csv', '--units', 'mm', '--side', 'both',
         '--exclude-dnp', pcb])
    offsets = {}
    if a.rot_offsets:
        with open(a.rot_offsets) as f:
            offsets = json.load(f)
    cpl_rows = []
    with open(pos_raw) as f:
        for r in csv.DictReader(f):
            rot = float(r['Rot'])
            for pat, deg in offsets.items():
                if re.search(pat, r['Package']):
                    rot = (rot + deg) % 360
            cpl_rows.append(dict(Designator=r['Ref'], **{'Mid X': r['PosX'], 'Mid Y': r['PosY']},
                                 Layer='Top' if r['Side'].lower() in ('top', 'front') else 'Bottom', Rotation='%g' % rot))
    cpl = os.path.join(out, name + '_cpl_jlc.csv')
    with open(cpl, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['Designator', 'Mid X', 'Mid Y', 'Layer', 'Rotation'])
        w.writeheader()
        w.writerows(cpl_rows)
    summary = dict(name=name, board_size_mm=[round(size[0], 2), round(size[1], 2)], copper_layers=len(cu),
                   footprints=fpcount, cpl_parts=len(cpl_rows))
    if a.cpl_fix:
        report = os.path.join(out, name + '_cpl_report.json')
        p = subprocess.run([sys.executable, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'jlc_cpl_fix.py'), pcb,
                            '--out', cpl, '--report', report, '--field', a.lcsc_field], capture_output=True, text=True)
        sys.stdout.write(p.stdout)
        if p.returncode:
            sys.stderr.write(p.stderr)
            raise SystemExit('CPL check failed')
        rep = json.load(open(report))
        summary.update(cpl_parts=len(rep), cpl_fix=dict(
            rotated={r['ref']: r['offset_deg'] for r in rep if r['offset_deg']},
            centre_shifted={r['ref']: r['centre_shift_mm'] for r in rep if max(abs(v) for v in r['centre_shift_mm']) >= 0.05},
            all_compatible=all(r['compatible'] for r in rep)))
    # schematic-side outputs
    if sch:
        bom_raw = os.path.join(out, 'bom_raw.csv')
        run(['kicad-cli', 'sch', 'export', 'bom', '-o', bom_raw, '--fields',
             'Reference,Value,Footprint,%s,${QUANTITY}' % a.lcsc_field, '--labels', 'Designator,Comment,Footprint,LCSC,Qty',
             '--group-by', 'Value,Footprint,%s' % a.lcsc_field, '--ref-range-delimiter', '', '--exclude-dnp', sch])
        bom_rows, missing, hand = [], [], []
        placed = {r['Designator'] for r in cpl_rows}
        with open(bom_raw) as f:
            for r in csv.DictReader(f):
                refs = [x.strip() for x in r['Designator'].split(',') if x.strip()]
                if not any(x in placed for x in refs):
                    continue                                  # not on the board (virtual, mechanical, excluded)
                lcsc = (r.get('LCSC') or '').strip()
                row = {'Comment': r['Comment'], 'Designator': ','.join(refs), 'Footprint': r['Footprint'].split(':')[-1], 'LCSC Part #': lcsc}
                if not lcsc:
                    missing.append(r['Designator'])
                    hand.append(row)                          # hand-soldered / not a purchasable part
                    continue
                bom_rows.append(row)
        merged = {}                                   # one line per LCSC part (JLC charges extended parts per part)
        for row in bom_rows:
            m = merged.setdefault(row['LCSC Part #'], dict(row, Designator='', Comment=''))
            m['Designator'] = ','.join(filter(None, [m['Designator'], row['Designator']]))
            if row['Comment'] not in m['Comment'].split('/'):
                m['Comment'] = '/'.join(filter(None, [m['Comment'], row['Comment']]))
        bom_rows = list(merged.values())
        if hand:
            with open(os.path.join(out, name + '_not_assembled.csv'), 'w', newline='') as f:
                w = csv.DictWriter(f, fieldnames=['Comment', 'Designator', 'Footprint', 'LCSC Part #'])
                w.writeheader()
                w.writerows(hand)
        bom = os.path.join(out, name + '_bom_jlc.csv')
        with open(bom, 'w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=['Comment', 'Designator', 'Footprint', 'LCSC Part #'])
            w.writeheader()
            w.writerows(bom_rows)
        run(['kicad-cli', 'sch', 'export', 'pdf', '-o', os.path.join(out, name + '_schematic.pdf'), sch])
        erc = os.path.join(out, name + '_erc.json')
        run(['kicad-cli', 'sch', 'erc', '--format', 'json', '--severity-all', '-o', erc, sch], check=False)
        summary.update(bom_lines=len(bom_rows), not_assembled=missing, erc=severity_counts(erc, 'erc'))
    drc = os.path.join(out, name + '_drc.json')
    drc_cmd = ['kicad-cli', 'pcb', 'drc', '--format', 'json', '--severity-all', '-o', drc]
    if sch:
        drc_cmd.append('--schematic-parity')
    run(drc_cmd + [pcb], check=False)
    summary['drc'] = severity_counts(drc, 'drc')
    for side in ('top', 'bottom'):
        run(['kicad-cli', 'pcb', 'render', '-o', os.path.join(out, '%s_%s.png' % (name, side)), '--side', side,
             '--width', '1600', '--height', '1200', '--quality', 'high', '--background', 'opaque', pcb], check=False)
    if a.step:
        run(['kicad-cli', 'pcb', 'export', 'step', '-o', os.path.join(out, name + '.step'), '--subst-models', pcb], check=False)
    for tmp in ('pos_raw.csv', 'bom_raw.csv'):
        if os.path.exists(os.path.join(out, tmp)):
            os.remove(os.path.join(out, tmp))
    summary['gerber_files'] = sorted(os.listdir(gdir))
    with open(os.path.join(out, 'summary.json'), 'w') as f:
        json.dump(summary, f, indent=1)
    print(json.dumps(summary, indent=1))


if __name__ == '__main__':
    main()
