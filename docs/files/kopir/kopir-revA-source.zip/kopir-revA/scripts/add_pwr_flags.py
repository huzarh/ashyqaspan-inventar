#!/usr/bin/env python3
# SPDX-License-Identifier: CERN-OHL-P-2.0
"""Add PWR_FLAG symbols to the six main-board nets that are powered from connectors (USB VBUS, shield, VBUS, +5V, +3V3,
GND) so ERC stops reporting 'power pin not driven'. Schematic only: power flags are not on the board. Idempotent."""
import os
import re
import sys
import uuid

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from make_wing import block_end, children  # noqa: E402

SCH = os.path.join(os.path.dirname(HERE), 'hardware', 'kopir-c3', 'kopir-c3.kicad_sch')
NS = uuid.UUID('0b5e7a0e-6f0b-4b7e-9d43-6f6e1a2c3d4e')
TARGETS = [('J1', 'A4_B9'), ('J1', 'S1'), ('U4', '26'), ('U5', '4'), ('D9', '1'), ('D9', '3')]   # ERC 'power pin not driven'


def transform(angle, mirror):
    """KiCad SCH_SYMBOL transform matrix (x1, y1, x2, y2) for '(at x y angle)' and '(mirror x|y)'."""
    def comp(t, temp):
        x1, y1, x2, y2 = t
        a1, b1, a2, b2 = temp
        return (x1 * a1 + x2 * b1, y1 * a1 + y2 * b1, x1 * a2 + x2 * b2, y1 * a2 + y2 * b2)
    t = (1, 0, 0, -1)
    for _ in range({0: 0, 90: 1, 180: 2, 270: 3}[angle]):
        t = comp(t, (0, 1, -1, 0))
    if mirror == 'y':
        t = comp(t, (-1, 0, 0, 1))
    elif mirror == 'x':
        t = comp(t, (1, 0, 0, -1))
    return t


def main():
    s = open(SCH, encoding='utf-8').read()
    if '"power:PWR_FLAG"' in s:
        print('PWR_FLAGs already present')
        return
    ls = s.index('\n\t(lib_symbols') + 2
    le = block_end(s, ls)
    libs = {}
    for h, a, e in children(s[ls:le]):
        blk = s[ls:le][a:e]
        pins = {}
        for m in re.finditer(r'\(pin \w+ \w+\s*\(at ([-\d.]+) ([-\d.]+) (\d+)\)(.*?)\(number "([^"]+)"', blk, re.S):
            pins[m.group(5)] = (float(m.group(1)), float(m.group(2)))
        libs[re.match(r'\(symbol "([^"]+)"', blk).group(1)] = pins
    points = {}
    for m in re.finditer(r'\n\t\(symbol\n\t\t\(lib_id "([^"]+)"\)\n\t\t\(at ([-\d.]+) ([-\d.]+) (\d+)\)(.*?)\n\t\)', s, re.S):
        lib, x, y, ang, rest = m.group(1), float(m.group(2)), float(m.group(3)), int(m.group(4)), m.group(5)
        ref = re.search(r'\(property "Reference" "([^"]+)"', rest).group(1)
        mir = re.search(r'\n\t\t\(mirror (\w)\)', rest)
        t = transform(ang, mir.group(1) if mir else None)
        for (r, pin) in TARGETS:
            if r == ref:
                px, py = libs[lib][pin]
                points[(r, pin)] = (round(x + t[0] * px + t[1] * py, 4), round(y + t[2] * px + t[3] * py, 4))
    wires = [tuple(map(float, m.groups())) for m in re.finditer(
        r'\(wire\s*\(pts\s*\(xy ([-\d.]+) ([-\d.]+)\)\s*\(xy ([-\d.]+) ([-\d.]+)\)', s)]
    root = re.search(r'\(instances\s*\(project ""\s*\(path "([^"]+)"', s).group(1)
    lib_txt = open('/usr/share/kicad/symbols/power.kicad_sym', encoding='utf-8').read()
    i = lib_txt.index('\n\t(symbol "PWR_FLAG"\n') + 2
    flag = lib_txt[i:block_end(lib_txt, i)].replace('(symbol "PWR_FLAG"', '(symbol "power:PWR_FLAG"', 1)
    flag = '\t\t' + '\n'.join(('\t' + l) if n else l for n, l in enumerate(flag.split('\n')))
    s = s[:le - 1].rstrip('\t') + flag + '\n\t)' + s[le:]
    items = []
    for n, key in enumerate(TARGETS, start=1):
        x, y = points[key]
        w = next(w for w in wires if (abs(w[0] - x) < 1e-3 and abs(w[1] - y) < 1e-3) or (abs(w[2] - x) < 1e-3 and abs(w[3] - y) < 1e-3))
        vertical = abs(w[0] - w[2]) < 1e-3
        rot = 270 if vertical else 0                     # flag points away from the wire it sits on
        vx, vy = (x + 3.81, y) if vertical else (x, y - 3.81)
        ref = '#FLG%04d' % (100 + n)
        u = lambda *k: str(uuid.uuid5(NS, '/'.join((ref,) + k)))
        hid = '(effects\n\t\t\t\t(font\n\t\t\t\t\t(size 1.27 1.27)\n\t\t\t\t)\n\t\t\t\t(hide yes)\n\t\t\t)'
        vis = '(effects\n\t\t\t\t(font\n\t\t\t\t\t(size 1.27 1.27)\n\t\t\t\t)%s\n\t\t\t)' % ('\n\t\t\t\t(justify left)' if vertical else '')
        items.append(
            '\t(symbol\n\t\t(lib_id "power:PWR_FLAG")\n\t\t(at %g %g %d)\n\t\t(unit 1)\n\t\t(exclude_from_sim no)\n\t\t(in_bom yes)\n'
            '\t\t(on_board yes)\n\t\t(dnp no)\n\t\t(uuid "%s")\n'
            '\t\t(property "Reference" "%s"\n\t\t\t(at %g %g 0)\n\t\t\t%s\n\t\t)\n'
            '\t\t(property "Value" "PWR_FLAG"\n\t\t\t(at %g %g 0)\n\t\t\t%s\n\t\t)\n'
            '\t\t(property "Footprint" ""\n\t\t\t(at %g %g 0)\n\t\t\t%s\n\t\t)\n'
            '\t\t(property "Datasheet" "~"\n\t\t\t(at %g %g 0)\n\t\t\t%s\n\t\t)\n'
            '\t\t(property "Description" "Special symbol for telling ERC where power comes from"\n\t\t\t(at %g %g 0)\n\t\t\t%s\n\t\t)\n'
            '\t\t(pin "1"\n\t\t\t(uuid "%s")\n\t\t)\n'
            '\t\t(instances\n\t\t\t(project ""\n\t\t\t\t(path "%s"\n\t\t\t\t\t(reference "%s")\n\t\t\t\t\t(unit 1)\n\t\t\t\t)\n\t\t\t)\n\t\t)\n\t)'
            % (x, y, rot, u('sym'), ref, x, y, hid, vx, vy, vis, x, y, hid, x, y, hid, x, y, hid, u('pin'), root, ref))
        print('%s on %s.%s at (%g, %g) rot %d' % (ref, key[0], key[1], x, y, rot))
    k = s.index('\n\t(sheet_instances')
    s = s[:k] + '\n' + '\n'.join(items) + s[k:]
    open(SCH, 'w', encoding='utf-8').write(s)


if __name__ == '__main__':
    main()
