#!/usr/bin/env python3
# SPDX-License-Identifier: CERN-OHL-P-2.0
"""Rev A BOM refresh (orderable at JLCPCB on 2026-11-10), applied to the schematic AND the PCB footprints."""
import sys

import pcbnew

sys.path.insert(0, __file__.rsplit('/', 1)[0])
from sch_edit import edit_symbol  # noqa: E402

SW_F = {'LCSC': 'C221895', 'MPN': 'PTS810SJG250SMTRLFS', 'Manufacturer': 'C&K',
        'Datasheet': 'https://www.lcsc.com/datasheet/lcsc_datasheet_2304140030_C-K-PTS810SJG250SMTRLFS_C221895.pdf'}
LRC_ESD = {'LCSC': 'C5274290', 'MPN': 'LESD5D5.0CT1G', 'Manufacturer': 'LRC'}
CHANGES = {
    'U3': dict(props={'Value': 'ESP32-C3-MINI-1-H4X', 'LCSC': 'C41349510', 'MPN': 'ESP32-C3-MINI-1-H4X', 'Manufacturer': 'Espressif Systems'}),
    'U2': dict(props={'LCSC': 'C3288646', 'MPN': 'ICM-42670-P', 'Manufacturer': 'TDK InvenSense'}),
    'J1': dict(props={'LCSC': 'C3020560', 'MPN': 'USB4105-GF-A', 'Manufacturer': 'GCT'}),
    'D5': dict(props=dict(LRC_ESD)), 'D7': dict(props=dict(LRC_ESD)), 'D8': dict(props=dict(LRC_ESD)),
    # upstream's WS2812B-MINI-V3/W (C527089) is out of JLC stock: same-family WS2812B-MINI-V6, identical land pattern and
    # pinout (checked against the LCSC footprint); the -V3J variant was rejected, its land pattern is mirrored
    'D9': dict(props={'Value': 'WS2812B', 'LCSC': 'C52941386', 'MPN': 'WS2812B-MINI-V6', 'Manufacturer': 'Worldsemi',
                      'Datasheet': 'https://www.tme.eu/Document/0ec02cd91c26984528fd69f9a2c14af9/WS2812B-MINI-V6_V1.2_EN.pdf'}),
    'U1': dict(props={'LCSC': 'C194656', 'MPN': 'SHTC3', 'Manufacturer': 'Sensirion'}, dnp=True),   # not needed on a drone
    # PTS810SJM250 (C116501) is down to a few hundred at JLCPCB: PTS810SJG250 from the same C&K family (same land pattern
    # and terminal pairing, firmer actuation - fine for BOOT/RESET on a drone)
    'SW1': dict(props=dict(SW_F)),
    'SW2': dict(props=dict(SW_F)),
    'Q1': dict(props={'MPN': 'DMG3415U-7', 'Manufacturer': 'Diodes Incorporated',
                      'Datasheet': 'https://www.lcsc.com/datasheet/lcsc_datasheet_1809191942_Diodes-Incorporated-DMG3415U-7_C96616.pdf'}),
}


def main(base):
    sch = base + '.kicad_sch'
    s = open(sch, encoding='utf-8').read()
    for ref, ch in CHANGES.items():
        s = edit_symbol(s, ref, ch.get('props'), ch.get('dnp'))
    open(sch, 'w', encoding='utf-8').write(s)
    board = pcbnew.LoadBoard(base + '.kicad_pcb')
    for ref, ch in CHANGES.items():
        fp = board.FindFootprintByReference(ref)
        for name, value in ch.get('props', {}).items():
            if name == 'Value':
                fp.SetValue(value)
            else:
                fp.SetField(name, value)
                fp.GetFieldByName(name).SetVisible(False)
        if ch.get('dnp') is not None:
            fp.SetDNP(ch['dnp'])
    pcbnew.SaveBoard(base + '.kicad_pcb', board)
    print('updated', ', '.join(CHANGES))


if __name__ == '__main__':
    main(sys.argv[1])
