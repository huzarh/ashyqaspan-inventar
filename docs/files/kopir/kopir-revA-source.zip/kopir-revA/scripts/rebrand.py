#!/usr/bin/env python3
# SPDX-License-Identifier: CERN-OHL-P-2.0
"""Rebrand the main board (CERN-OHL-P 7.2: no licensor names/logos except factually) and add the 3.3(b)/4 notices.
Tracks, pads and vias are not touched: only the logo artwork footprints (including the esp-rs copper logo on the top
side), silkscreen/mask/fab texts and the title blocks change, and the zones are refilled. hygiene.py then finishes the
silkscreen (1.0 mm lines) and the title block comments. Two load/save phases (pcbnew segfaults when edited objects are
reused after removals); safe to run twice: an already branded board and its schematic are left alone."""
import re
import sys

import pcbnew

sys.path.insert(0, __file__.rsplit('/', 1)[0])
from logo_to_silk import add_logo  # noqa: E402

REMOVE_FP = {'G***', 'kibuzzard-623DAB98', 'kibuzzard-61E1AB2E'}
REMOVE_TEXT = {'ESP-RS', 'ESP32-C3-DevKit-RUST-2\nv2.0 10/2025', 'github.com/esp-rs', 'Rust Board 2.0', '2544'}
FAB_TEXT = {'ESPRESSIF SYSTEMS': 'ASHYQ ASPAN FOUNDATION', 'ESP32-C3-DevKit-RUST-2': 'KOPIR C3 rev A (from ESP32-C3-DevKit-RUST-2 rev 2.0)',
            '2025-10-28': '2026-11-10', 'Rev 2.0': 'Rev A'}
TITLE = dict(title='Köpir C3 — Ashyq Aspan FC companion bridge', company='Ashyq Aspan Foundation', rev='A', date='2026-11-10',
             comments=['Derived from ESP32-C3-DevKit-RUST-2 rev 2.0 by Espressif Systems / esp-rs',
                       'github.com/esp-rs/esp-rust-board - CERN-OHL-P-2.0, provided without warranty',
                       'Modified 2026-11-10 by Ashyq Aspan Foundation: BOM, notices, rebranding (NOTICE.md)',
                       'No track, pad or via changes. Drone I/O: Köpir Wing add-on'])     # same as hygiene.COMMENTS
MARK = 'KÖPIR C3'
MM = pcbnew.FromMM


def text(board, s, x, y, h, layer, bold=False, thick=None):
    t = pcbnew.PCB_TEXT(board)
    t.SetText(s)
    t.SetLayer(board.GetLayerID(layer))
    t.SetPosition(pcbnew.VECTOR2I(MM(x), MM(y)))
    t.SetTextSize(pcbnew.VECTOR2I(MM(h), MM(h)))
    t.SetTextThickness(MM(thick or max(0.15, h * 0.15)))
    t.SetBold(bold)
    if layer.startswith('B.'):
        t.SetMirrored(True)
    board.Add(t)


def phase1(pcb):
    b = pcbnew.LoadBoard(pcb)
    texts = [d for d in b.GetDrawings() if d.GetClass() == 'PCB_TEXT' and d.GetText() in REMOVE_TEXT]
    for t in texts:
        b.Remove(t)
    fps = [fp for fp in b.GetFootprints() if fp.GetReference() in REMOVE_FP]
    names = [fp.GetReference() + '@' + fp.GetFPIDAsString() for fp in fps]
    for fp in fps:
        b.Remove(fp)
    pcbnew.SaveBoard(pcb, b)
    return [t.replace('\n', ' ') for t in REMOVE_TEXT], names


def fit_text(board, s, x, y, layer, max_w, h=0.9, min_h=0.8, bold=False):
    """Add text centred at (x, y), shrinking it (down to min_h) until it is no wider than max_w (mm)."""
    while True:
        t = pcbnew.PCB_TEXT(board)
        t.SetText(s)
        t.SetLayer(board.GetLayerID(layer))
        t.SetPosition(pcbnew.VECTOR2I(MM(x), MM(y)))
        t.SetTextSize(pcbnew.VECTOR2I(MM(h), MM(h)))
        t.SetTextThickness(MM(max(0.15, h * 0.16)))
        t.SetBold(bold)
        if layer.startswith('B.'):
            t.SetMirrored(True)
        w = pcbnew.ToMM(t.GetBoundingBox().GetWidth())
        if w <= max_w or h <= min_h + 1e-6:
            board.Add(t)
            if w > max_w:
                raise SystemExit('text too wide even at %.2f mm: %r (%.1f > %.1f mm)' % (h, s, w, max_w))
            return round(h, 2), round(w, 1)
        h = max(min_h, h - 0.05)


def phase2(pcb, logo):
    b = pcbnew.LoadBoard(pcb)
    if any(d.GetClass() == 'PCB_TEXT' and d.GetText() == MARK for d in b.GetDrawings()):
        return 'already branded'
    for d in b.GetDrawings():
        if d.GetClass() == 'PCB_TEXT' and b.GetLayerName(d.GetLayer()) == 'F.Fab' and d.GetText() in FAB_TEXT:
            d.SetText(FAB_TEXT[d.GetText()])
    # leftover silkscreen frames of the removed name boxes (old 'Espressif Systems / github' box and the '2544' box)
    frames = []
    for d in b.GetDrawings():
        if d.GetClass() == 'PCB_SHAPE' and b.GetLayerName(d.GetLayer()) == 'B.Silkscreen':
            bb = d.GetBoundingBox()
            cx, cy = pcbnew.ToMM(bb.GetCenter().x), pcbnew.ToMM(bb.GetCenter().y)
            if (140.5 <= cx <= 155.7 and 82.3 <= cy <= 84.8) or (146.0 <= cx <= 150.1 and 121.0 <= cy <= 123.3):
                frames.append(d)
    for d in frames:
        b.Remove(d)
    placed = {}
    add_logo(b, logo, 139.75, 118.9, 4.6, 'F.SilkS')               # where the top ESP-RS artwork was
    add_logo(b, logo, 148.08, 73.0, 9.0, 'B.SilkS')                # where the big bottom gear was
    # the antenna-end strip between the mounting holes stays empty. (The first pass put a JLCJLCJLCJLC order-number marker
    # and two workshop-site URL lines there; JLCPCB prints no order numbers since May 2026 and the URL did not lead to
    # the design files, so hygiene.py removes them from boards branded by that pass.)
    placed['name'] = fit_text(b, MARK, 148.08, 79.5, 'B.SilkS', 17.5, h=2.0, min_h=1.5, bold=True)
    placed['rev'] = fit_text(b, 'rev A · 2026-11-10', 148.08, 81.85, 'B.SilkS', 17.5, h=0.9)
    placed['org'] = fit_text(b, 'ASHYQ ASPAN FOUNDATION', 148.08, 83.25, 'B.SilkS', 17.5, h=0.9)
    # attribution band below pin 16, where the original name/version text was
    placed['n1'] = fit_text(b, 'Derived from Espressif', 148.08, 116.05, 'B.SilkS', 17.6, h=0.85)
    placed['n2'] = fit_text(b, 'ESP32-C3-DevKit-RUST-2', 148.08, 117.2, 'B.SilkS', 17.6, h=0.85)
    placed['n3'] = fit_text(b, 'CERN-OHL-P-2.0', 148.08, 118.35, 'B.SilkS', 17.6, h=0.85)
    tb = b.GetTitleBlock()
    tb.SetTitle(TITLE['title'])
    tb.SetCompany(TITLE['company'])
    tb.SetRevision(TITLE['rev'])
    tb.SetDate(TITLE['date'])
    for i, c in enumerate(TITLE['comments']):
        tb.SetComment(i, c)
    filler = pcbnew.ZONE_FILLER(b)
    filler.Fill(b.Zones())
    pcbnew.SaveBoard(pcb, b)
    return dict(frames_removed=len(frames), text_mm=placed)


def schematic_title(sch):
    s = open(sch, encoding='utf-8').read()
    tb_new = '(title_block\n\t\t(title "%s")\n\t\t(date "%s")\n\t\t(rev "%s")\n\t\t(company "%s")\n%s\t)' % (
        TITLE['title'], TITLE['date'], TITLE['rev'], TITLE['company'],
        ''.join('\t\t(comment %d "%s")\n' % (i + 1, c) for i, c in enumerate(TITLE['comments'])))
    s, n = re.subn(r'\(title_block\n(?:\t\t[^\n]*\n)*?\t\)', tb_new, s, count=1)
    if n != 1:
        raise SystemExit('schematic title block not found')
    open(sch, 'w', encoding='utf-8').write(s)


if __name__ == '__main__':
    # every phase runs in its own interpreter: pcbnew.LoadBoard() returns a broken object when called twice in one process
    import subprocess
    if len(sys.argv) == 4:
        base, logo, phase = sys.argv[1:]
        if phase == '1':
            print('phase 1 removed:', phase1(base + '.kicad_pcb'))
        else:
            done = phase2(base + '.kicad_pcb', logo)
            print('phase 2:', done)
            if done != 'already branded':
                schematic_title(base + '.kicad_sch')
                print('schematic title block updated')
    else:
        for ph in ('1', '2'):
            subprocess.run([sys.executable, __file__, sys.argv[1], sys.argv[2], ph], check=True)
