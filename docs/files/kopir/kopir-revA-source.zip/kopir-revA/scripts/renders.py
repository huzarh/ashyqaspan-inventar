#!/usr/bin/env python3
# SPDX-License-Identifier: CERN-OHL-P-2.0
"""README image art/kopir-renders.png, rendered from the current boards. Run it after any board change and before
scripts/release.py, which packs the image with the README:

    python3 scripts/renders.py [--cover cover.jpg] [--keep DIR]

kicad-cli renders the top and bottom of both boards (transparent background); Pillow crops each render to the board,
scales all four to the same mm-per-pixel and sets them side by side with captions. --cover also writes a 16:9 image
of Köpir C3 (top and bottom) and the wing's component side; --keep saves the raw renders.
"""
import argparse
import json
import os
import shutil
import subprocess
import tempfile

from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VIEWS = [('kopir-c3', 'top', 'Köpir C3 — top'), ('kopir-c3', 'bottom', 'Köpir C3 — bottom'),
         ('kopir-wing', 'top', 'Köpir Wing — component side'), ('kopir-wing', 'bottom', 'Köpir Wing — main board side')]
LENGTH_MM = {'kopir-c3': 63.5, 'kopir-wing': 44.0}      # fallback when fab/<board>/summary.json is missing
FONT = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'


def board_length(board):
    path = os.path.join(ROOT, 'fab', board, 'summary.json')
    if os.path.exists(path):
        return json.load(open(path))['board_size_mm'][1]
    return LENGTH_MM[board]


def render(board, side, out):
    subprocess.run(['kicad-cli', 'pcb', 'render', '--side', side, '--quality', 'high', '--background', 'transparent',
                    '--width', '1200', '--height', '1500', '-o', out,
                    os.path.join(ROOT, 'hardware', board, board + '.kicad_pcb')], check=True, capture_output=True, timeout=900)


def load(path, mm, px_per_mm):
    """Crop a render to the board and scale it so that 1 mm of board length is px_per_mm pixels."""
    im = Image.open(path).convert('RGBA')
    im = im.crop(im.getchannel('A').point(lambda a: 255 if a > 20 else 0).getbbox())
    s = px_per_mm * mm / im.height
    return im.resize((int(im.width * s), int(im.height * s)), Image.LANCZOS)


def composite(views, out):
    font = ImageFont.truetype(FONT, 26) if os.path.exists(FONT) else ImageFont.load_default()
    ims = [(load(path, mm, 18), label) for path, mm, label in views]
    h = max(im.height for im, _ in ims)
    w = sum(im.width for im, _ in ims) + 60 * (len(ims) + 1)
    c = Image.new('RGBA', (w, h + 110), (250, 250, 248, 255))
    d = ImageDraw.Draw(c)
    x = 60
    for im, label in ims:
        c.alpha_composite(im, (x, 30 + h - im.height))         # boards stand on a common baseline
        tw = d.textlength(label, font=font)
        d.text((x + (im.width - tw) / 2, h + 55), label, fill=(30, 30, 30, 255), font=font)
        x += im.width + 60
    c.convert('RGB').save(out, optimize=True)
    return c.size


def cover(views, out, size=(1600, 900), gap=110):
    ims = [load(path, mm, 12.6) for path, mm, _ in views]
    total = sum(im.width for im in ims) + gap * (len(ims) - 1)
    cv = Image.new('RGBA', size, (255, 255, 255, 255))
    x = (size[0] - total) // 2
    base = (size[1] + max(im.height for im in ims)) // 2
    for im in ims:
        y = base - im.height
        shadow = Image.new('RGBA', im.size, (0, 0, 0, 0))
        shadow.putalpha(im.getchannel('A').point(lambda a: int(a * 0.35)))
        cv.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(14)), (x + 10, y + 14))
        cv.alpha_composite(im, (x, y))
        x += im.width + gap
    cv.convert('RGB').save(out, quality=90)
    return cv.size


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default=os.path.join(ROOT, 'art', 'kopir-renders.png'))
    ap.add_argument('--cover', help='also write a 16:9 cover image (JPEG)')
    ap.add_argument('--keep', help='directory for the raw renders')
    a = ap.parse_args()
    tmp = tempfile.mkdtemp()
    views = []
    for board, side, label in VIEWS:
        path = os.path.join(tmp, '%s_%s.png' % (board, side))
        render(board, side, path)
        views.append((path, board_length(board), label))
        print('rendered', board, side)
    print('composite', composite(views, a.out), a.out)
    if a.cover:
        print('cover', cover(views[:3], a.cover), a.cover)
    if a.keep:
        os.makedirs(a.keep, exist_ok=True)
        for path, _, _ in views:
            shutil.copy(path, a.keep)
    shutil.rmtree(tmp)


if __name__ == '__main__':
    main()
