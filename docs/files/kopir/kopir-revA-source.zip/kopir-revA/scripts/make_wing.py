#!/usr/bin/env python3
# SPDX-License-Identifier: CERN-OHL-P-2.0
"""Köpir Wing rev A - drone I/O add-on for Köpir C3 (derivative of Espressif's ESP32-C3-DevKit-RUST-2, Feather-style 16 + 12 pins).

The whole design lives in this file and is regenerated from it:
    python3 scripts/make_wing.py          -> hardware/kopir-wing/kopir-wing.{kicad_pro,kicad_sch,kicad_pcb} + sym-lib-table
    python3 scripts/make_wing.py check    -> ERC, DRC with schematic parity (JSON reports in /tmp/kopir-wing-*.json)
Phase 'sch' writes the schematic from KiCad 9 library symbols (global labels on every used pin, no-connect flags elsewhere).
Phase 'pcb' takes nets and symbol paths from the schematic netlist (kicad-cli), so the board always matches the schematic,
then places the parts (every SMD part on the top face, single-sided assembly), routes, pours GND on both layers and adds
the silkscreen. The wing mounts component side down under the main board; headers enter from its back.
Ashyq Aspan Foundation, 2026-11-10. CERN-OHL-P-2.0.
"""
import json
import math
import os
import re
import subprocess
import sys
import textwrap
import uuid

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, 'hardware', 'kopir-wing')
NAME = 'kopir-wing'
SCH = os.path.join(OUT, NAME + '.kicad_sch')
PCB = os.path.join(OUT, NAME + '.kicad_pcb')
SYMDIR = '/usr/share/kicad/symbols'
FPDIR = '/usr/share/kicad/footprints'
LOGO = os.path.join(ROOT, 'art', 'ashyq_aspan_logo.png')
NS = uuid.UUID('6f1d7c1e-0a55-4c0b-9a1e-6b6f7a7a5e01')
DATE, REV = '2026-11-10', 'A'
TITLE = 'Köpir Wing — drone I/O add-on for Köpir C3'


def U(*key):
    return str(uuid.uuid5(NS, '/'.join(map(str, key))))


ROOT_UUID = U('root')

# ------------------------------------------------------------------ circuit (single source of truth)
JST = 'Connector_JST:JST_SH_SM04B-SRSS-TB_1x04-1MP_P1.00mm_Horizontal'
JST_F = {'LCSC': 'C160404', 'MPN': 'SM04B-SRSS-TB(LF)(SN)', 'Manufacturer': 'JST'}
R470_F = {'LCSC': 'C25117', 'MPN': '0402WGF4700TCE', 'Manufacturer': 'UNI-ROYAL'}
R1K_F = {'LCSC': 'C11702', 'MPN': '0402WGF1001TCE', 'Manufacturer': 'UNI-ROYAL'}
R0402 = 'Resistor_SMD:R_0402_1005Metric'
HDR = 'hand-soldered 2.54 mm header (female or stacking) mating with main board pins '
PARTS = [
    dict(ref='J1', lib='Connector_Generic:Conn_01x16', value='MAIN 1-16', fp='Connector_PinHeader_2.54mm:PinHeader_1x16_P2.54mm_Vertical',
         pins={'2': '+3V3', '4': 'GND', '5': 'IO0', '6': 'IO1', '7': 'IO2', '9': 'IO4', '10': 'IO5', '12': 'IO7_SDA', '13': 'IO8_SCL'},
         fields={'Note': HDR + '1-16; socket 3 blocked as the key'}, sch=(50.8, 63.5)),
    dict(ref='J5', lib='Connector_Generic:Conn_01x12', value='MAIN 17-28', fp='Connector_PinHeader_2.54mm:PinHeader_1x12_P2.54mm_Vertical',
         pins={'10': 'VBUS'}, fields={'Note': HDR + '17-28; sockets 1-2 blocked as the key'}, sch=(50.8, 139.7)),
    dict(ref='J2', lib='Connector_Generic_MountingPin:Conn_01x04_MountingPin', value='FC', fp=JST,
         pins={'1': 'GND', '2': 'FC_5V', '3': 'FC_TX', '4': 'FC_RX', 'MP': 'GND'}, fields=JST_F, sch=(243.84, 45.72)),
    dict(ref='J3', lib='Connector_Generic_MountingPin:Conn_01x04_MountingPin', value='I2C', fp=JST,
         pins={'1': 'GND', '2': '+3V3', '3': 'IO7_SDA', '4': 'IO8_SCL', 'MP': 'GND'}, fields=JST_F, sch=(243.84, 88.9)),
    dict(ref='J4', lib='Connector_Generic_MountingPin:Conn_01x04_MountingPin', value='AUX', fp=JST,
         pins={'1': 'GND', '2': 'VBUS_AUX', '3': 'AUX_TX', '4': 'AUX_RX', 'MP': 'GND'}, fields=JST_F, sch=(243.84, 132.08)),
    dict(ref='F1', lib='Device:Polyfuse', value='0.75A 30V', fp='Fuse:Fuse_1206_3216Metric', pins={'1': 'FC_5V', '2': '+5V_FC'},
         fields={'LCSC': 'C7542953', 'MPN': '1206L075/30NR', 'Manufacturer': 'LUTE'}, sch=(190.5, 45.72)),
    # Diode:SMF5V0A (extends SM6T6V8A) names its pins A1/A2, but pin 1 is the cathode bar of the unidirectional TVS graphic
    dict(ref='D1', lib='Diode:SMF5V0A', value='SMF5.0A', fp='Diode_SMD:D_SMF', pins={'1': '+5V_FC', '2': 'GND'}, names={'1': 'A1', '2': 'A2'},
         pad_functions={'1': 'K', '2': 'A'}, fields={'LCSC': 'C193402', 'MPN': 'SMF5.0A', 'Manufacturer': 'MDD'}, sch=(139.7, 45.72)),
    dict(ref='C1', lib='Device:C', value='10uF 25V', fp='Capacitor_SMD:C_0805_2012Metric', pins={'1': '+5V_FC', '2': 'GND'},
         fields={'LCSC': 'C15850', 'MPN': 'CL21A106KAYNNNE', 'Manufacturer': 'Samsung Electro-Mechanics'}, sch=(165.1, 45.72)),
    dict(ref='D2', lib='Device:D_Schottky', value='B5819W', fp='Diode_SMD:D_SOD-123', pins={'1': 'VBUS', '2': '+5V_FC'}, names={'1': 'K', '2': 'A'},
         fields={'LCSC': 'C8598', 'MPN': 'B5819W'}, sch=(101.6, 45.72)),
    dict(ref='F2', lib='Device:Polyfuse', value='0.35A', fp='Fuse:Fuse_0805_2012Metric', pins={'1': 'VBUS', '2': 'VBUS_AUX'},
         fields={'LCSC': 'C20977', 'MPN': 'SMD0805P035TF', 'Manufacturer': 'RUILON'}, sch=(152.4, 129.54)),
    dict(ref='R1', lib='Device:R', value='10kR 1%', fp=R0402, pins={'1': 'IO2', '2': '+3V3'},
         fields={'LCSC': 'C25744', 'MPN': '0402WGF1002TCE', 'Manufacturer': 'UNI-ROYAL'}, sch=(101.6, 91.44)),
    dict(ref='R2', lib='Device:R', value='470R 1%', fp=R0402, pins={'1': 'IO4', '2': 'FC_TX'}, fields=R470_F, sch=(127.0, 91.44)),
    dict(ref='R3', lib='Device:R', value='1kR 1%', fp=R0402, pins={'1': 'IO5', '2': 'FC_RX'}, fields=R1K_F, sch=(152.4, 91.44)),
    dict(ref='R4', lib='Device:R', value='470R 1%', fp=R0402, pins={'1': 'IO0', '2': 'AUX_TX'}, fields=R470_F, sch=(101.6, 129.54)),
    dict(ref='R5', lib='Device:R', value='1kR 1%', fp=R0402, pins={'1': 'IO1', '2': 'AUX_RX'}, fields=R1K_F, sch=(127.0, 129.54)),
]
NOTES = [
    'Köpir Wing rev A - drone I/O add-on, mounts under Köpir C3 on its 2.54 mm header pins (all SMD parts on the outer face).',
    'J2 FC (JST-SH 4): 1 GND, 2 +5 V in from the FC BEC (F1 0.75 A/30 V PTC, D1 TVS, C1, D2 Schottky -> VBUS), '
    '3 TX out (IO4 via R2) -> FC RX, 4 RX in (IO5 via R3) <- FC TX.',
    'J3 I2C (Qwiic pinout): 1 GND, 2 3V3, 3 SDA (IO7), 4 SCL (IO8). Shared with the on-board IMU; 10k pull-ups R17/R18 are on the main board.',
    'J4 AUX UART: 1 GND, 2 VBUS out through F2 (0.35 A PTC), 3 TX (IO0 via R4), 4 RX (IO1 via R5): same order as J2, so a 1:1 cable fits '
    'GND/5V/RX/TX sensors such as the MicoAir MTF-01. AUX 5 V exists only on USB or FC power, not on the main board battery. '
    'IO0/IO1 are free because the main board does not fit Y1 (32 kHz).',
    'R1: GPIO2 strapping pull-up (on the main board GPIO2 only drives the RGB LED through R11).',
    'R2-R5: 470R on outputs, 1k on inputs keep clamp currents to a few mA when a 5 V UART or a powered peripheral meets an unpowered '
    'ESP32-C3 (its pins are not 5 V tolerant).',
    'Power: D6 on the main board blocks VBUS back-feed into USB; D2 blocks USB 5 V back into the FC. J2 pin 2 is for a regulated 5 V BEC only: '
    'a battery on it makes D1 clamp until F1 trips (D1 is then likely destroyed). 3.3 V logic only on TX/RX/SDA/SCL.',
    'Keying: cut pins 3, 17 and 18 (N/C) of the main board headers and block sockets J1-3, J5-1 and J5-2. With both rows engaged '
    'the wing then cannot be fitted rotated, shifted along the rows or on top; a sideways fit on one row is not keyed, so check '
    'that both rows engage before powering.',
]

# ------------------------------------------------------------------ S-expression helpers


def block_end(s, start):
    """Index just past the parenthesised block starting at s[start] == '('."""
    depth, k = 0, start
    while True:
        c = s[k]
        if c == '"':
            k += 1
            while s[k] != '"':
                k += 2 if s[k] == '\\' else 1
        elif c == '(':
            depth += 1
        elif c == ')':
            depth -= 1
            if depth == 0:
                return k + 1
        k += 1


def children(blk):
    """Top-level child blocks of a block: list of (head, start, end) relative to blk."""
    out, k, depth = [], 1, 0
    while k < len(blk) - 1:
        c = blk[k]
        if c == '"':
            k += 1
            while blk[k] != '"':
                k += 2 if blk[k] == '\\' else 1
        elif c == '(':
            e = block_end(blk, k)
            out.append((re.match(r'\((\S+)', blk[k:e]).group(1), k, e))
            k = e
            continue
        k += 1
    return out


def parse_sexpr(text):
    toks = re.findall(r'"(?:[^"\\]|\\.)*"|\(|\)|[^\s()"]+', text)
    stack, cur = [], []
    for t in toks:
        if t == '(':
            stack.append(cur)
            cur = []
        elif t == ')':
            done, cur = cur, stack.pop()
            cur.append(done)
        else:
            cur.append(t[1:-1].replace('\\"', '"').replace('\\\\', '\\') if t.startswith('"') else t)
    return cur[0]


def lib_block(lib, name):
    text = open(os.path.join(SYMDIR, lib + '.kicad_sym'), encoding='utf-8').read()
    i = text.index('\n\t(symbol "%s"\n' % name) + 2
    return text[i:block_end(text, i)]


def lib_symbol(lib_id):
    """Library symbol as embedded in a schematic (derived symbols flattened like LIB_SYMBOL::Flatten)."""
    lib, name = lib_id.split(':')
    blk = lib_block(lib, name)
    m = re.search(r'\(extends "([^"]+)"\)', blk)
    if m:
        parent_name = m.group(1)
        parent = lib_block(lib, parent_name)
        if '(extends' in parent:
            raise SystemExit('nested derived symbols are not supported: ' + lib_id)
        dprops = {}
        for head, a, e in children(blk):
            if head == 'property':
                dprops[re.match(r'\(property "([^"]+)"', blk[a:e]).group(1)] = blk[a:e]
        parts, last, used = [], 0, set()
        kids = children(parent)
        last_prop = max(e for h, a, e in kids if h == 'property')
        for head, a, e in kids:
            parts.append(parent[last:a])
            chunk = parent[a:e]
            if head == 'property':
                pname = re.match(r'\(property "([^"]+)"', chunk).group(1)
                if pname in dprops:
                    chunk = dprops[pname]
                    used.add(pname)
            elif head == 'symbol':
                chunk = chunk.replace('(symbol "%s_' % parent_name, '(symbol "%s_' % name, 1)
            parts.append(chunk)
            if e == last_prop:
                for pname, pblk in dprops.items():
                    if pname not in used:
                        parts.append('\n\t\t' + pblk)
                used.update(dprops)
            last = e
        parts.append(parent[last:])
        blk = ''.join(parts).replace('(symbol "%s"' % parent_name, '(symbol "%s"' % name, 1)
    blk = blk.replace('(symbol "%s"' % name, '(symbol "%s"' % lib_id, 1)
    pins = {}
    for pm in re.finditer(r'\(pin \w+ \w+\s*\(at ([-\d.]+) ([-\d.]+) (\d+)\)(.*?)\(name "([^"]*)"(.*?)\(number "([^"]+)"', blk, re.S):
        pins.setdefault(pm.group(7), []).append((float(pm.group(1)), float(pm.group(2)), int(pm.group(3)), pm.group(5)))
    props = dict(re.findall(r'\(property "([^"]+)" "((?:[^"\\]|\\.)*)"', blk))
    return '\n'.join('\t' + line for line in ('\t' + blk).split('\n')), pins, props


def fmt(v):
    return ('%.4f' % v).rstrip('0').rstrip('.')


def q(s):
    return '"%s"' % s.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n')


def eff(hide=False, justify=None):
    j = '\n\t\t\t\t(justify %s)' % justify if justify else ''
    h = '\n\t\t\t\t(hide yes)' if hide else ''
    return '(effects\n\t\t\t\t(font\n\t\t\t\t\t(size 1.27 1.27)\n\t\t\t\t)%s%s\n\t\t\t)' % (j, h)


def make_schematic():
    libs = {}
    for p in PARTS:
        if p['lib'] not in libs:
            libs[p['lib']] = lib_symbol(p['lib'])
    out = ['(kicad_sch', '\t(version 20250114)', '\t(generator "eeschema")', '\t(generator_version "9.0")',
           '\t(uuid %s)' % q(ROOT_UUID), '\t(paper "A4")',
           '\t(title_block\n\t\t(title %s)\n\t\t(date %s)\n\t\t(rev %s)\n\t\t(company "Ashyq Aspan Foundation")\n'
           '\t\t(comment 1 "FC port with protected 5 V input, Qwiic I2C port, AUX UART, GPIO2 strapping pull-up")\n'
           '\t\t(comment 2 "Mates with Köpir C3 (derived from ESP32-C3-DevKit-RUST-2 by Espressif Systems)")\n'
           '\t\t(comment 3 "Licensed under CERN-OHL-P-2.0. Provided without warranty.")\n\t)' % (q(TITLE), q(DATE), q(REV)),
           '\t(lib_symbols']
    out += [libs[k][0] for k in libs]
    out.append('\t)')
    items = []
    for p in PARTS:
        blk, pinmap, lprops = libs[p['lib']]
        sx, sy = p['sch']
        for num, want in p.get('names', {}).items():
            got = pinmap[num][0][3]
            if got != want:
                raise SystemExit('%s pin %s is %r in %s, expected %r' % (p['ref'], num, got, p['lib'], want))
        missing = set(p['pins']) - set(pinmap)
        if missing:
            raise SystemExit('%s: pins %s not in symbol %s' % (p['ref'], sorted(missing), p['lib']))
        for num, ends in sorted(pinmap.items()):
            for (px, py, ang, _name) in ends:
                x, y = sx + px, sy - py
                net = p['pins'].get(num)
                if net is None:
                    items.append('\t(no_connect\n\t\t(at %s %s)\n\t\t(uuid %s)\n\t)' % (fmt(x), fmt(y), q(U('nc', p['ref'], num))))
                    continue
                la = {0: 180, 180: 0, 90: 270, 270: 90}[ang]
                just = 'right' if la in (180, 270) else 'left'
                items.append('\t(global_label %s\n\t\t(shape bidirectional)\n\t\t(at %s %s %d)\n\t\t(fields_autoplaced yes)\n\t\t%s\n'
                             '\t\t(uuid %s)\n\t\t(property "Intersheetrefs" "${INTERSHEET_REFS}"\n\t\t\t(at %s %s 0)\n\t\t\t%s\n\t\t)\n\t)'
                             % (q(net), fmt(x), fmt(y), la, eff(justify=just).replace('\n\t\t\t', '\n\t\t'), q(U('lbl', p['ref'], num)),
                                fmt(x), fmt(y), eff(hide=True)))
        props = [('Reference', p['ref'], False, (sx + 2.54, sy - 6.35)), ('Value', p['value'], False, (sx + 2.54, sy + 6.35)),
                 ('Footprint', p['fp'], True, (sx, sy)), ('Datasheet', lprops.get('Datasheet', '~'), True, (sx, sy)),
                 ('Description', lprops.get('Description', ''), True, (sx, sy))]
        props += [(k, v, True, (sx, sy)) for k, v in p.get('fields', {}).items()]
        pr = ''.join('\t\t(property %s %s\n\t\t\t(at %s %s 0)\n\t\t\t%s\n\t\t)\n' % (q(k), q(v), fmt(a), fmt(b), eff(hide=h, justify='left'))
                     for k, v, h, (a, b) in props)
        pins = ''.join('\t\t(pin %s\n\t\t\t(uuid %s)\n\t\t)\n' % (q(num), q(U('pin', p['ref'], num))) for num in sorted(pinmap))
        items.append('\t(symbol\n\t\t(lib_id %s)\n\t\t(at %s %s 0)\n\t\t(unit 1)\n\t\t(exclude_from_sim no)\n\t\t(in_bom yes)\n\t\t(on_board yes)\n'
                     '\t\t(dnp no)\n\t\t(uuid %s)\n%s%s\t\t(instances\n\t\t\t(project %s\n\t\t\t\t(path %s\n\t\t\t\t\t(reference %s)\n'
                     '\t\t\t\t\t(unit 1)\n\t\t\t\t)\n\t\t\t)\n\t\t)\n\t)'
                     % (q(p['lib']), fmt(sx), fmt(sy), q(U('sym', p['ref'])), pr, pins, q(NAME), q('/' + ROOT_UUID), q(p['ref'])))
    items.append('\t(text %s\n\t\t(exclude_from_sim no)\n\t\t(at 22.86 160.02 0)\n\t\t(effects\n\t\t\t(font\n\t\t\t\t(size 1.27 1.27)\n\t\t\t)\n'
                 '\t\t\t(justify left top)\n\t\t)\n\t\t(uuid %s)\n\t)'
                 % (q('\n'.join(textwrap.fill(n, 100, subsequent_indent='    ') for n in NOTES)), q(U('notes'))))
    out += items
    out += ['\t(sheet_instances\n\t\t(path "/"\n\t\t\t(page "1")\n\t\t)\n\t)', '\t(embedded_fonts no)', ')']
    with open(SCH, 'w', encoding='utf-8') as f:
        f.write('\n'.join(out) + '\n')


def write_project():
    pro = json.load(open(os.path.join(ROOT, 'hardware', 'kopir-c3', 'kopir-c3.kicad_pro')))
    pro['meta']['filename'] = NAME + '.kicad_pro'
    pro['sheets'] = [[ROOT_UUID, 'Root']]
    pro['board']['design_settings']['drc_exclusions'] = []
    pro['board']['design_settings']['rules'].update(JLC_SETUP)
    pro.setdefault('erc', {})['erc_exclusions'] = []
    pro['boards'] = []
    pro['text_variables'] = {}
    with open(os.path.join(OUT, NAME + '.kicad_pro'), 'w') as f:
        json.dump(pro, f, indent=2)
        f.write('\n')
    libs = sorted({p['lib'].split(':')[0] for p in PARTS})
    with open(os.path.join(OUT, 'sym-lib-table'), 'w') as f:
        f.write('(sym_lib_table\n\t(version 7)\n')
        for lib in libs:
            f.write('\t(lib (name "%s")(type "KiCad")(uri "${KICAD9_SYMBOL_DIR}/%s.kicad_sym")(options "")(descr "KiCad 9 standard library"))\n'
                    % (lib, lib))
        f.write(')\n')
    with open(os.path.join(OUT, NAME + '.kicad_dru'), 'w') as f:
        f.write(JLC_RULES)


# ------------------------------------------------------------------ board geometry
# The wing is assembled on its top (F) side and mounts component side down, so its F side faces away from the main
# board and the header bodies sit on its B side. Seen from the F side, the main board's pin rows appear mirrored:
# copper coordinates below are written in the main board's top view and reflected about the centre line (MX).
# Silkscreen positions are written directly in the wing's own (front) view.
X0, X1, Y0, Y1 = 136.652, 159.512, 73.5, 117.5     # main board width, clear of its battery pads / USB shell
JLC_RULES = """(version 1)
# JLCPCB standard 2-layer capabilities, checked by 'make_wing.py check'. Unconditional minimums (track 0.127, clearance
# 0.127, copper to edge 0.3, hole to hole 0.5, silkscreen text 1.0 / 0.15) are floors in the board setup (kicad_pro),
# so they do not override the pours' own 0.25 mm clearance.
(rule "JLC via drill and annular ring"
\t(condition "A.Type == 'Via'")
\t(constraint hole_size (min 0.3mm))
\t(constraint annular_width (min 0.13mm)))
(rule "JLC plated hole to copper"
\t(condition "A.isPlated()")
\t(constraint hole_clearance (min 0.28mm)))
(rule "JLC pad to silkscreen"
\t(layer outer)
\t(condition "A.Type == 'Pad' && (B.Type == 'Text' || B.Type == 'Graphic')")
\t(constraint silk_clearance (min 0.15mm)))
"""
JLC_SETUP = dict(min_clearance=0.127, min_track_width=0.127, min_copper_edge_clearance=0.3, min_hole_to_hole=0.5,
                 min_hole_clearance=0.25, min_via_annular_width=0.13, min_through_hole_diameter=0.3,
                 min_text_height=1.0, min_text_thickness=0.15)


def MX(x):
    return round(X0 + X1 - x, 4)


XL, YL1 = MX(137.922), 76.454      # main board pin 1: left row in its top view (pins 1..16 downwards)
XR, YR17 = MX(158.242), 114.554    # main board pin 17: right row in its top view (pins 17..28 upwards)
FRONT, BACK = 'F.Cu', 'B.Cu'       # component side, main board side


def HL(n):
    return (XL, YL1 + 2.54 * (n - 1))


def HR(k):                          # wing J5 pin k == main board pin 16 + k
    return (XR, YR17 - 2.54 * (k - 1))


PLACE = {   # ref: (x, y, angle, side); headers go on the back so their outline marks where the plastic sits
    'J1': (XL, YL1, 0, 'B'), 'J5': (XR, YR17, 180, 'B'),
    'J4': (MX(148.1), 76.6, 180, 'F'),    # AUX, plug enters from the antenna-end edge
    'J3': (MX(143.7), 114.4, 0, 'F'),     # I2C, plug enters from the USB-end edge
    'J2': (MX(152.0), 114.4, 0, 'F'),     # FC, plug enters from the USB-end edge
    'R4': (MX(141.0), HL(5)[1], 180, 'F'), 'R5': (MX(141.0), HL(6)[1], 180, 'F'), 'R1': (MX(141.0), HL(7)[1], 180, 'F'),
    'R2': (MX(141.0), HL(9)[1], 180, 'F'), 'R3': (MX(141.0), HL(10)[1], 180, 'F'),
    # power column, stacked from the FC connector upwards: F1 PTC, D1 TVS, C1, D2 Schottky
    'F1': (MX(152.8), 108.8, 90, 'F'), 'D1': (MX(154.0), 105.1, 180, 'F'), 'C1': (MX(154.0), 102.7, 180, 'F'),
    'D2': (MX(152.5), 99.1, 270, 'F'),
    'F2': (MX(155.2), 87.0, 90, 'F'),     # AUX supply PTC
}
EXPECT = {('J2', '2'): (MX(152.5), 112.4), ('J2', '3'): (MX(151.5), 112.4), ('J3', '2'): (MX(144.2), 112.4), ('J3', '3'): (MX(143.2), 112.4),
          ('J4', '2'): (MX(147.6), 78.6), ('J4', '4'): (MX(149.6), 78.6), ('R4', '1'): (MX(140.49), HL(5)[1]), ('D2', '1'): (MX(152.5), 97.45),
          ('C1', '1'): (MX(153.05), 102.7), ('D1', '1'): (MX(152.55), 105.1), ('F1', '1'): (MX(152.8), 110.2),
          ('F2', '1'): (MX(155.2), 87.9375), ('J5', '10'): HR(10), ('J1', '16'): HL(16)}
W_SIG, W_3V3, W_PWR = 0.25, 0.4, 0.6
VIA = (0.6, 0.3)


def netlist():
    tmp = '/tmp/%s.net' % NAME
    subprocess.run(['kicad-cli', 'sch', 'export', 'netlist', '--format', 'kicadsexpr', '-o', tmp, SCH], check=True, capture_output=True)
    tree = parse_sexpr(open(tmp, encoding='utf-8').read())
    get = lambda node, key: next((c for c in node[1:] if isinstance(c, list) and c and c[0] == key), None)
    comps, nets, funcs = {}, {}, {}
    for comp in get(tree, 'components')[1:]:
        ref = get(comp, 'ref')[1]
        sheet = get(get(comp, 'sheetpath'), 'tstamps')[1]
        stamp = (get(comp, 'tstamps') or get(comp, 'tstamp'))[1]
        comps[ref] = dict(path=sheet.rstrip('/') + '/' + stamp, value=get(comp, 'value')[1], fp=get(comp, 'footprint')[1])
    for net in get(tree, 'nets')[1:]:
        name = get(net, 'name')[1]
        for node in net[1:]:
            if isinstance(node, list) and node[0] == 'node':
                key = (get(node, 'ref')[1], get(node, 'pin')[1])
                nets[key] = name
                pf = get(node, 'pinfunction')
                if pf:
                    funcs[key] = pf[1]
    return comps, nets, funcs


def make_board():
    import pcbnew
    sys.path.insert(0, HERE)
    from logo_to_silk import add_logo
    MM = pcbnew.FromMM
    V = lambda x, y: pcbnew.VECTOR2I(MM(x), MM(y))
    LID = lambda name: getattr(pcbnew, name.replace('.', '_'))     # a fresh BOARD() does not resolve 'B.SilkS' by name
    comps, padnets, padfuncs = netlist()
    b = pcbnew.BOARD()
    b.SetCopperLayerCount(2)
    nets = {}

    def net(name):
        if name not in nets:
            ni = pcbnew.NETINFO_ITEM(b, name)
            b.Add(ni)
            nets[name] = ni
        return nets[name]

    for (xa, ya, xb, yb) in ((X0, Y0, X1, Y0), (X1, Y0, X1, Y1), (X1, Y1, X0, Y1), (X0, Y1, X0, Y0)):
        s = pcbnew.PCB_SHAPE(b)
        s.SetShape(pcbnew.SHAPE_T_SEGMENT)
        s.SetLayer(pcbnew.Edge_Cuts)
        s.SetWidth(MM(0.05))
        s.SetStart(V(xa, ya))
        s.SetEnd(V(xb, yb))
        b.Add(s)
    fps = {}
    for p in PARTS:
        ref, c = p['ref'], comps[p['ref']]
        if c['fp'] != p['fp'] or c['value'] != p['value']:
            raise SystemExit('netlist disagrees with PARTS for ' + ref)
        lib, name = p['fp'].split(':')
        fp = pcbnew.FootprintLoad(os.path.join(FPDIR, lib + '.pretty'), name)
        fp.SetFPIDAsString(p['fp'])
        b.Add(fp)                                  # must belong to the board before Flip()
        fp.SetReference(ref)
        fp.SetValue(p['value'])
        _, _, lprops = lib_symbol(p['lib'])
        for k, v in [('Datasheet', lprops.get('Datasheet', '~')), ('Description', lprops.get('Description', ''))] + list(p.get('fields', {}).items()):
            f = fp.GetFieldByName(k)
            if f is None:
                fp.SetField(k, v)
                f = fp.GetFieldByName(k)
            f.SetText(v)
            f.SetVisible(False)
        fp.SetPath(pcbnew.KIID_PATH(c['path']))
        fp.SetSheetname('/')
        fp.SetSheetfile(NAME + '.kicad_sch')
        x, y, ang, side = PLACE[ref]
        fp.SetPosition(V(x, y))
        fp.SetOrientationDegrees(ang)
        if side == 'B':
            fp.Flip(V(x, y), pcbnew.FLIP_DIRECTION_LEFT_RIGHT)
        for g in fp.GraphicalItems():              # JLC: silkscreen lines >= 0.15 mm, nothing that runs past the board edge
            if g.GetClass() != 'PCB_SHAPE' or g.GetLayer() not in (pcbnew.F_SilkS, pcbnew.B_SilkS):
                continue
            xs = [pcbnew.ToMM(g.GetStart().x), pcbnew.ToMM(g.GetEnd().x)]
            if side == 'B' and (min(xs) < X0 + 0.15 or max(xs) > X1 - 0.15):
                g.SetLayer(pcbnew.B_Fab)           # (FOOTPRINT.Remove() leaves the SWIG proxy unusable)
            elif ref.startswith('R'):
                g.SetLayer(pcbnew.F_Fab)           # 0402 ticks sit 0.1 mm from the pads
            else:
                g.SetWidth(max(g.GetWidth(), MM(0.15)))
        for pad in fp.Pads():
            n = padnets.get((ref, pad.GetNumber()))
            if n:
                pad.SetNet(net(n))
            fn = p.get('pad_functions', {}).get(pad.GetNumber()) or padfuncs.get((ref, pad.GetNumber()))
            if fn:
                pad.SetPinFunction(fn)             # lets jlc_cpl_fix.py prove polarity by pin name
        fps[ref] = fp

    def P(ref, num):
        pads = [q_ for q_ in fps[ref].Pads() if q_.GetNumber() == num]
        c = pads[0].GetPosition()
        return (round(pcbnew.ToMM(c.x), 4), round(pcbnew.ToMM(c.y), 4))

    for (ref, num), (ex, ey) in EXPECT.items():
        gx, gy = P(ref, num)
        if abs(gx - ex) > 0.01 or abs(gy - ey) > 0.01:
            raise SystemExit('%s.%s at (%.3f, %.3f), expected (%.3f, %.3f)' % (ref, num, gx, gy, ex, ey))

    def track(netname, layer, width, pts):
        lid = LID(layer)
        for (xa, ya), (xb, yb) in zip(pts[:-1], pts[1:]):
            t = pcbnew.PCB_TRACK(b)
            t.SetLayer(lid)
            t.SetWidth(MM(width))
            t.SetStart(V(xa, ya))
            t.SetEnd(V(xb, yb))
            t.SetNet(net(netname))
            b.Add(t)

    def via(netname, x, y):
        v = pcbnew.PCB_VIA(b)
        b.Add(v)
        v.SetPosition(V(x, y))
        v.SetWidth(MM(VIA[0]))
        v.SetDrill(MM(VIA[1]))
        v.SetNet(net(netname))
        return v

    # header pins -> series / pull-up resistors (component side, straight)
    for n, ref in ((5, 'R4'), (6, 'R5'), (7, 'R1'), (9, 'R2'), (10, 'R3')):
        track(padnets[(ref, '1')], FRONT, W_SIG, [HL(n), P(ref, '1')])
    # resistor -> connector: across, then straight into the pad
    for ref, jref, jpin in (('R4', 'J4', '3'), ('R5', 'J4', '4'), ('R2', 'J2', '3'), ('R3', 'J2', '4')):
        a, j = P(ref, '2'), P(jref, jpin)
        track(padnets[(ref, '2')], FRONT, W_SIG, [a, (j[0], a[1]), j])
    # I2C: header 12/13 -> J3.3/J3.4
    for n, jpin in ((12, '3'), (13, '4')):
        h, j = HL(n), P('J3', jpin)
        track(padnets[('J1', str(n))], FRONT, W_SIG, [h, (j[0], h[1]), j])
    # +3V3 runs on the back (main board side, only header pads there): pin 2 -> J3.2 and R1.2
    j32, r12 = P('J3', '2'), P('R1', '2')
    track('+3V3', BACK, W_3V3, [HL(2), (j32[0], HL(2)[1]), (j32[0], 110.0)])
    via('+3V3', j32[0], 110.0)
    track('+3V3', FRONT, W_3V3, [(j32[0], 110.0), j32])
    track('+3V3', FRONT, W_SIG, [r12, (MX(142.5), r12[1])])
    via('+3V3', MX(142.5), r12[1])
    track('+3V3', BACK, W_SIG, [(MX(142.5), r12[1]), (j32[0], r12[1])])
    # VBUS: main board pin 26 -> D2 cathode; branch -> F2 -> VBUS_AUX, which crosses the AUX signals on the back to J4.2
    vb, d2k, f21, f22, j42 = HR(10), P('D2', '1'), P('F2', '1'), P('F2', '2'), P('J4', '2')
    track('VBUS', FRONT, W_PWR, [vb, (d2k[0], vb[1]), d2k])
    track('VBUS', FRONT, W_PWR, [(f21[0], vb[1]), f21])
    ya = 80.4
    track('VBUS_AUX', FRONT, W_3V3, [f22, (f22[0], ya)])
    via('VBUS_AUX', f22[0], ya)
    track('VBUS_AUX', BACK, W_PWR, [(f22[0], ya), (j42[0], ya)])
    via('VBUS_AUX', j42[0], ya)
    track('VBUS_AUX', FRONT, W_3V3, [(j42[0], ya), j42])
    # FC 5 V: J2.2 -> F1 -> +5V_FC spine through D1.1 and C1.1 to the D2 anode
    j22, f11, f12, d2a, c11, d11 = P('J2', '2'), P('F1', '1'), P('F1', '2'), P('D2', '2'), P('C1', '1'), P('D1', '1')
    track('FC_5V', FRONT, W_PWR, [j22, f11])
    track('+5V_FC', FRONT, W_PWR, [f12, (f12[0], d2a[1]), d2a])     # spine runs inside the D1.K, C1.1 and D2.A pads
    track('+5V_FC', FRONT, W_PWR, [(f12[0], c11[1]), c11])
    track('+5V_FC', FRONT, W_PWR, [(f12[0], d11[1]), d11])
    # GND: short stubs + vias next to every ground pad (the pours do the rest)
    gnd_vias = []
    for (ref, num), (vx, vy) in {('J4', '1'): (P('J4', '1')[0], 80.6), ('J3', '1'): (P('J3', '1')[0], 110.5),
                                 ('J2', '1'): (MX(154.4), 110.9), ('C1', '2'): (MX(156.3), P('C1', '2')[1]),
                                 ('D1', '2'): (P('D1', '2')[0], 106.75)}.items():
        track('GND', FRONT, W_PWR if ref in ('C1', 'D1') else W_SIG + 0.05, [P(ref, num), (vx, vy)])
        gnd_vias.append(via('GND', vx, vy))

    # ---------------------------------------------------------------- silkscreen (positions in the wing's front view)
    def box_mm(bb, grow=0.0):
        return (pcbnew.ToMM(bb.GetX()) - grow, pcbnew.ToMM(bb.GetY()) - grow, pcbnew.ToMM(bb.GetRight()) + grow, pcbnew.ToMM(bb.GetBottom()) + grow)

    def overlap(a, c):
        return a[0] < c[2] and c[0] < a[2] and a[1] < c[3] and c[1] < a[3]

    vias_now = lambda: [box_mm(t.GetBoundingBox()) for t in b.GetTracks() if t.GetClass() == 'PCB_VIA']
    pads_on = lambda layer: [box_mm(pd.GetBoundingBox()) for fp in fps.values() for pd in fp.Pads()
                             if pd.IsOnLayer(pcbnew.F_Cu if layer == 'F.SilkS' else pcbnew.B_Cu)]
    texts, placed = [], {'F.SilkS': [], 'B.SilkS': []}
    for fp in fps.values():
        for g in fp.GraphicalItems():
            for layer, lid in (('F.SilkS', pcbnew.F_SilkS), ('B.SilkS', pcbnew.B_SilkS)):
                if g.GetLayer() == lid:
                    placed[layer].append(box_mm(g.GetBoundingBox()))

    def ink(t, grow=0.0):
        try:                                       # stroke extents, not the (taller) text frame
            return box_mm(t.GetEffectiveTextShape().BBox(), grow)
        except Exception:
            return box_mm(t.GetBoundingBox(), grow)

    def text(s, x, y, h, layer='F.SilkS', bold=False, left=False, slide=0.0):
        """Silkscreen text at (x, y). If it would touch a pad, via or other silkscreen, slide it sideways (up to 'slide'
        mm), then try slightly narrower characters (height stays >= 1 mm for JLC)."""
        t = pcbnew.PCB_TEXT(b)
        t.SetText(s)
        if left:
            t.SetHorizJustify(pcbnew.GR_TEXT_H_ALIGN_LEFT)
        t.SetLayer(LID(layer))
        t.SetBold(bold)
        t.SetTextThickness(MM(max(0.15, h * (0.2 if bold else 0.15))))
        if layer.startswith('B.'):
            t.SetMirrored(True)
        b.Add(t)
        obstacles = [o for o in pads_on(layer) + vias_now()] + placed[layer]
        steps = [0.0] + [d * k for k in range(1, int(slide / 0.1) + 1) for d in (0.1, -0.1)]
        for scale in (1.0, 0.92, 0.85):
            t.SetTextSize(pcbnew.VECTOR2I(MM(h * scale), MM(h)))
            for dx in steps:
                t.SetPosition(V(x + dx, y))
                bb = ink(t, 0.15)
                if bb[0] >= X0 + 0.3 and bb[2] <= X1 - 0.3 and not any(overlap(bb, o) for o in obstacles):
                    placed[layer].append(ink(t))
                    texts.append(t)
                    return t
        t.SetPosition(V(x, y))
        bb = ink(t, 0.15)
        hits = [o for o in obstacles if overlap(bb, o)]
        raise SystemExit('no room for silkscreen text %r at (%.2f, %.2f) on %s: box %s hits %s'
                         % (s, x, y, layer, tuple(round(v, 2) for v in bb), [tuple(round(v, 2) for v in o) for o in hits[:4]]))

    def triangle(cx, cy, size, direction, layer):
        """Filled arrow head pointing 'up' / 'down' / 'right' (wing front-view directions)."""
        h = size / 2
        pts = {'up': [(cx, cy - h), (cx - h, cy + h), (cx + h, cy + h)], 'down': [(cx, cy + h), (cx - h, cy - h), (cx + h, cy - h)],
               'right': [(cx + h, cy), (cx - h, cy - h), (cx - h, cy + h)],
               'left': [(cx - h, cy), (cx + h, cy - h), (cx + h, cy + h)]}[direction]
        poly = pcbnew.SHAPE_POLY_SET()
        poly.NewOutline()
        for px, py in pts:
            poly.Append(MM(px), MM(py))
        s = pcbnew.PCB_SHAPE(b)
        s.SetShape(pcbnew.SHAPE_T_POLY)
        s.SetPolyShape(poly)
        s.SetFilled(True)
        s.SetWidth(MM(0.1))
        s.SetLayer(LID(layer))
        b.Add(s)
        placed[layer].append(box_mm(s.GetBoundingBox()))

    def legend(ref):
        """Pin names left to right as they appear on the component side."""
        short = {'GND': 'G', 'FC_5V': '5V', 'VBUS_AUX': '5V', '+3V3': '3V3', 'IO7_SDA': 'SDA', 'IO8_SCL': 'SCL',
                 'FC_TX': 'TX', 'FC_RX': 'RX', 'AUX_TX': 'TX', 'AUX_RX': 'RX'}
        pads = sorted((pd for pd in fps[ref].Pads() if pd.GetNumber() in '1234'), key=lambda pd: pd.GetPosition().x)
        return ' '.join(short[pd.GetNetname()] for pd in pads)

    # component side
    text('KÖPIR WING', 147.3, 82.6, 1.4, bold=True)          # left of the KEY mark at J1 pin 3
    text('rev %s · %s' % (REV, DATE), 148.08, 84.5, 1.0)
    for i, (name, ref) in enumerate((('FC', 'J2'), ('I2C', 'J3'), ('AUX', 'J4'))):
        text(name, 139.6, 92.9 + 1.4 * i, 1.0, left=True)
        text(legend(ref), 143.4, 92.9 + 1.4 * i, 1.0, left=True)
    text('ASHYQ ASPAN', 151.0, 100.9, 1.0, slide=1.5)
    text('CERN-OHL-P-2.0', 151.0, 102.4, 1.0, slide=1.5)
    text('AUX', 141.8, 77.4, 1.0, slide=1.0)
    text('FC', 147.0, 110.7, 1.0, slide=1.0)
    text('I2C', 154.4, 110.7, 1.0, slide=1.0)
    text('KEY', 154.8, 80.9, 1.0, slide=0.4)
    triangle(156.7, 80.9, 0.7, 'right', 'F.SilkS')
    for ref in ('J2', 'J3', 'J4', 'R1', 'R2', 'R3', 'R4', 'R5', 'F1', 'F2', 'D1', 'D2', 'C1'):
        fps[ref].Reference().SetVisible(False)     # refdes live on the fab layer; the outer face carries function labels
    n_logo, _ = add_logo(b, LOGO, 149.6, 107.6, 4.0, 'F.SilkS')
    # main board side: orientation and keys
    triangle(148.08, 74.25, 0.8, 'up', 'B.SilkS')
    text('ANTENNA END', 148.08, 75.6, 1.0, layer='B.SilkS')
    triangle(148.08, 116.75, 0.8, 'down', 'B.SilkS')
    text('USB-C END', 148.08, 115.4, 1.0, layer='B.SilkS')
    text('KÖPIR WING', 148.08, 93.4, 1.2, layer='B.SilkS', bold=True, slide=1.0)
    text('MAIN BOARD SIDE', 148.08, 95.1, 1.0, layer='B.SilkS', slide=1.0)
    text('KEY', 154.8, 80.9, 1.0, layer='B.SilkS', slide=0.4)   # the header outline frames the pin on this side
    text('KEY', 142.1, HR(1)[1] - 1.27, 1.0, layer='B.SilkS', slide=0.4)    # J5 sockets 1-2 (main pins 17-18)
    triangle(140.25, HR(1)[1] - 1.27, 0.7, 'left', 'B.SilkS')
    for ref, (x, y) in {'J1': (155.6, 75.3), 'J5': (140.6, 110.0)}.items():
        rt = fps[ref].Reference()
        rt.SetTextSize(V(1.0, 1.0))
        rt.SetTextThickness(MM(0.15))
        rt.SetPosition(V(x, y))
        placed['B.SilkS'].append(box_mm(rt.GetBoundingBox()))

    # stitching vias on a grid wherever they clear every other copper item, text, silkscreen and part body
    def dist_box(x, y, bx):
        dx = max(bx[0] - x, 0, x - bx[2])
        dy = max(bx[1] - y, 0, y - bx[3])
        return math.hypot(dx, dy)

    def dist_seg(x, y, a, c):
        (ax, ay), (cx, cy) = a, c
        L = (cx - ax) ** 2 + (cy - ay) ** 2
        t = 0 if L == 0 else max(0, min(1, ((x - ax) * (cx - ax) + (y - ay) * (cy - ay)) / L))
        return math.hypot(x - ax - t * (cx - ax), y - ay - t * (cy - ay))

    segs = [(t.GetNetname(), pcbnew.ToMM(t.GetWidth()), (pcbnew.ToMM(t.GetStart().x), pcbnew.ToMM(t.GetStart().y)),
             (pcbnew.ToMM(t.GetEnd().x), pcbnew.ToMM(t.GetEnd().y))) for t in b.GetTracks() if t.GetClass() == 'PCB_TRACK']
    vias = [(pcbnew.ToMM(t.GetPosition().x), pcbnew.ToMM(t.GetPosition().y)) for t in b.GetTracks() if t.GetClass() == 'PCB_VIA']
    pads = [box_mm(pd.GetBoundingBox()) for fp in fps.values() for pd in fp.Pads()]
    keepout = [(o[0] - 0.2, o[1] - 0.2, o[2] + 0.2, o[3] + 0.2) for o in placed['F.SilkS'] + placed['B.SilkS']]
    keepout += [box_mm(d.GetBoundingBox(), 0.2) for d in b.GetDrawings() if d.GetLayer() in (pcbnew.B_SilkS, pcbnew.F_SilkS)]
    for fp in fps.values():
        if fp.GetLayer() == pcbnew.F_Cu:
            fab = [box_mm(g.GetBoundingBox()) for g in fp.GraphicalItems() if g.GetLayer() == pcbnew.F_Fab]
            if fab:
                keepout.append((min(f[0] for f in fab), min(f[1] for f in fab), max(f[2] for f in fab), max(f[3] for f in fab)))
    r = VIA[0] / 2
    chosen = []
    y = Y0 + 1.2
    while y < Y1 - 1.0:
        x = X0 + 1.4
        while x < X1 - 1.0:
            ok = all(dist_seg(x, y, a, c) >= r + w / 2 + 0.25 for nn, w, a, c in segs if nn != 'GND')
            ok = ok and all(dist_box(x, y, bx) >= r + 0.3 for bx in pads)
            ok = ok and all(dist_box(x, y, bx) > r for bx in keepout)
            ok = ok and all(math.hypot(x - vx, y - vy) >= 2.0 for vx, vy in vias + chosen)
            if ok:
                chosen.append((round(x, 3), round(y, 3)))
            x += 1.27
        y += 1.27
    stitch = []
    for (x, y) in chosen:
        if all(math.hypot(x - sx, y - sy) >= 3.4 for sx, sy in stitch):
            stitch.append((x, y))
    for (x, y) in stitch:
        via('GND', x, y)

    for layer in (FRONT, BACK):
        z = pcbnew.ZONE(b)
        z.SetLayer(LID(layer))
        z.SetNet(net('GND'))
        z.SetLocalClearance(MM(0.25))
        z.SetMinThickness(MM(0.2))
        z.SetPadConnection(pcbnew.ZONE_CONNECTION_THERMAL)
        z.SetThermalReliefGap(MM(0.3))
        z.SetThermalReliefSpokeWidth(MM(0.35))
        o = z.Outline()
        o.NewOutline()
        for (px, py) in ((X0 + 0.3, Y0 + 0.3), (X1 - 0.3, Y0 + 0.3), (X1 - 0.3, Y1 - 0.3), (X0 + 0.3, Y1 - 0.3)):
            o.Append(MM(px), MM(py))
        b.Add(z)
    tb = b.GetTitleBlock()
    tb.SetTitle(TITLE)
    tb.SetCompany('Ashyq Aspan Foundation')
    tb.SetRevision(REV)
    tb.SetDate(DATE)
    tb.SetComment(0, 'Drone I/O add-on for Köpir C3 (derived from ESP32-C3-DevKit-RUST-2 by Espressif Systems)')
    tb.SetComment(1, 'Top-side assembly; mounts component side down under Köpir C3, headers on the back.')
    tb.SetComment(2, 'CERN-OHL-P-2.0. Provided without warranty.')
    b.SetTitleBlock(tb)
    pcbnew.SaveBoard(PCB, b, True)          # zones are filled by the 'fill' phase (needs a board loaded with its project)
    # same stackup and finish as the main board (black mask, white silkscreen, ENIG, 1.6 mm)
    main = open(os.path.join(ROOT, 'hardware', 'kopir-c3', 'kopir-c3.kicad_pcb'), encoding='utf-8').read()
    i = main.index('(stackup')
    s = open(PCB, encoding='utf-8').read()
    if '(stackup' not in s:
        k = s.index('(setup') + len('(setup')
        s = s[:k] + '\n\t\t' + main[i:block_end(main, i)] + s[k:]
        open(PCB, 'w', encoding='utf-8').write(s)
    print('board: %d footprints, %d tracks, %d GND vias (%d stitching), logo %d polygons, %d texts'
          % (len(fps), len(segs), len(gnd_vias) + len(stitch), len(stitch), n_logo, len(texts)))


def fill():
    import pcbnew
    b = pcbnew.LoadBoard(PCB)
    b.BuildConnectivity()
    pcbnew.ZONE_FILLER(b).Fill(b.Zones())
    pcbnew.SaveBoard(PCB, b, True)
    print('zones filled:', ', '.join('%s %s %.0f mm2' % (z.GetNetname(), '+'.join(b.GetLayerName(l) for l in z.GetLayerSet().Seq()),
                                                       z.GetFilledArea() / 1e12) for z in b.Zones()))


def check():
    rep = {}
    for kind, cmd in (('erc', ['kicad-cli', 'sch', 'erc', '--severity-all', '--format', 'json', '-o', '/tmp/kopir-wing-erc.json', SCH]),
                      ('drc', ['kicad-cli', 'pcb', 'drc', '--schematic-parity', '--severity-all', '--format', 'json',
                               '-o', '/tmp/kopir-wing-drc.json', PCB])):
        subprocess.run(cmd, check=True, capture_output=True)
        d = json.load(open('/tmp/kopir-wing-%s.json' % kind))
        items = []
        if kind == 'erc':
            for sh in d.get('sheets', []):
                items += sh.get('violations', [])
        else:
            items = d.get('violations', []) + d.get('unconnected_items', []) + d.get('schematic_parity', [])
        rep[kind] = items
        print('%s: %d items' % (kind.upper(), len(items)))
        for it in items:
            where = '; '.join('%s @(%.2f,%.2f)' % (i.get('description', ''), i.get('pos', {}).get('x', 0), i.get('pos', {}).get('y', 0))
                              for i in it.get('items', []))
            print('  [%s] %s: %s | %s' % (it.get('severity'), it.get('type'), it.get('description'), where[:240]))
    return rep


if __name__ == '__main__':
    phase = sys.argv[1] if len(sys.argv) > 1 else 'all'
    if phase == 'all':
        subprocess.run([sys.executable, __file__, 'sch'], check=True)
        subprocess.run([sys.executable, __file__, 'pcb'], check=True)
        subprocess.run([sys.executable, __file__, 'fill'], check=True)
    elif phase == 'sch':
        os.makedirs(OUT, exist_ok=True)
        write_project()
        make_schematic()
        print('schematic: %d symbols' % len(PARTS))
    elif phase == 'pcb':
        make_board()
        write_project()
    elif phase == 'fill':
        fill()
    elif phase == 'check':
        check()
