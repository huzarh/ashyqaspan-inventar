#!/usr/bin/env python3
# SPDX-License-Identifier: CERN-OHL-P-2.0
"""JLCPCB assembly stock / library-type / price check for BOM files, and keyword search for alternatives.

    python3 jlc_parts.py fab/kopir-c3/kopir-c3-revA_bom_jlc.csv [more BOMs] --qty 10 --json parts.json
    python3 jlc_parts.py --search "WS2812B 3535"

Library type: 'base' = JLC basic part (no feeder fee), 'expand' = extended part (one-off fee per unique part),
'preferred' flag = JLC "preferred extended" (fee waived for economic assembly). Stock is JLC's own assembly stock,
which can differ from LCSC's shop stock.
"""
import argparse
import csv
import json
import sys
import time
import urllib.request

API = 'https://jlcpcb.com/api/overseas-pcb-order/v1/shoppingCart/smtGood/selectSmtComponentList'


def query(keyword, size=10):
    body = json.dumps({'keyword': keyword, 'currentPage': 1, 'pageSize': size}).encode()
    for attempt in range(6):
        try:
            req = urllib.request.Request(API, data=body, headers={'Content-Type': 'application/json', 'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=30) as r:
                d = json.load(r)
            return (d.get('data') or {}).get('componentPageInfo', {}).get('list') or []
        except Exception as e:                    # flaky uplink: retry with backoff
            err = e
            time.sleep(2 + 3 * attempt)
    raise RuntimeError('JLC API failed for %s: %s' % (keyword, err))


def summarize(it, qty=1):
    prices = sorted(it.get('componentPrices') or [], key=lambda p: p['startNumber'])
    unit = next((p['productPrice'] for p in prices if p['startNumber'] <= qty and (p['endNumber'] == -1 or qty <= p['endNumber'])),
                prices[0]['productPrice'] if prices else None)
    lib = it.get('componentLibraryType')
    return dict(lcsc=it.get('componentCode'), mpn=it.get('componentModelEn'), brand=it.get('componentBrandEn'),
                package=it.get('componentSpecificationEn'), type=it.get('componentTypeEn'), library=lib,
                preferred=bool(it.get('preferredComponentFlag')), stock=it.get('stockCount'), unit_price=unit,
                describe=(it.get('describe') or '')[:160], url=it.get('lcscGoodsUrl'), datasheet=it.get('dataManualUrl'))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('boms', nargs='*')
    ap.add_argument('--qty', type=int, default=10, help='boards to build (stock and price tier check)')
    ap.add_argument('--json')
    ap.add_argument('--search')
    a = ap.parse_args()
    if a.search:
        for it in query(a.search, 25):
            s = summarize(it)
            print('%-10s %-26s %-16s %-14s %-7s pref=%-5s stock=%-8s $%s  %s' % (s['lcsc'], (s['mpn'] or '')[:26], (s['brand'] or '')[:16],
                  (s['package'] or '')[:14], s['library'], s['preferred'], s['stock'], s['unit_price'], s['describe'][:70]))
        return
    out, problems = {}, []
    for bom in a.boms:
        rows = list(csv.DictReader(open(bom)))
        total, extended = 0.0, []
        print('== %s (%d boards)' % (bom, a.qty))
        for r in rows:
            code = r['LCSC Part #']
            n = len([x for x in r['Designator'].split(',') if x.strip()])
            hits = [it for it in query(code) if it.get('componentCode') == code]
            if not hits:
                problems.append('%s %s: not found at JLCPCB' % (bom, code))
                print('  %-10s NOT FOUND' % code)
                continue
            s = summarize(hits[0], n * a.qty)
            s.update(designators=r['Designator'], per_board=n, comment=r['Comment'])
            out.setdefault(bom, []).append(s)
            total += n * (s['unit_price'] or 0)
            if s['library'] != 'base' and not s['preferred']:
                extended.append(code)
            need = n * a.qty
            flag = '' if (s['stock'] or 0) >= need * 5 else ('  <-- OUT OF STOCK' if not s['stock'] else '  <-- LOW STOCK')
            if flag:
                problems.append('%s %s %s: JLC stock %s for %d needed' % (bom, code, s['mpn'], s['stock'], need))
            print('  %-10s %-24s %-14s %-6s%-5s stock %-8s $%-7s x%d %s%s' % (code, (s['mpn'] or '')[:24], (s['package'] or '')[:14], s['library'],
                  '*' if s['preferred'] else '', s['stock'], s['unit_price'], n, r['Designator'][:20], flag))
        print('  parts per board: $%.2f; extended parts (fee each): %d %s' % (total, len(extended), ' '.join(extended)))
    if a.json:
        json.dump(dict(qty=a.qty, boms=out, problems=problems), open(a.json, 'w'), indent=1, ensure_ascii=False)
    if problems:
        print('\n'.join(['PROBLEMS:'] + problems))
        sys.exit(1)


if __name__ == '__main__':
    main()
