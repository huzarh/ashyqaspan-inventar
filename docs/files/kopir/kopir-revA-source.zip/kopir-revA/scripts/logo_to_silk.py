#!/usr/bin/env python3
# SPDX-License-Identifier: CERN-OHL-P-2.0
"""Place a raster logo on a KiCad board as filled silkscreen polygons (with holes), using pcbnew.

    python3 logo_to_silk.py board.kicad_pcb logo.png --x 20 --y 12 --width 8 --layer F.SilkS [--invert] [--out out.kicad_pcb]

The logo pixels are selected by brightness (white shape on a coloured background by default). Thin features are
protected by a minimum feature size (JLCPCB silkscreen: >= 0.15 mm lines).
"""
import argparse

import cv2
import numpy as np
import pcbnew


def logo_polys(png, width_mm, min_feature_mm=0.16, invert=False, thresh=200):
    img = cv2.imread(png, cv2.IMREAD_UNCHANGED)
    if img.shape[2] == 4:
        alpha = img[..., 3]
        rgb = img[..., :3]
    else:
        alpha = np.full(img.shape[:2], 255, np.uint8)
        rgb = img
    bright = (rgb.min(axis=2) >= thresh) & (alpha > 128)
    mask = (~bright if invert else bright) & (alpha > 128)
    ys, xs = np.nonzero(mask)
    x0, x1, y0, y1 = xs.min(), xs.max(), ys.min(), ys.max()
    mask = mask[y0:y1 + 1, x0:x1 + 1].astype(np.uint8) * 255
    scale = 8                                            # supersample, then clean features at the target resolution
    mask = cv2.resize(mask, (mask.shape[1] * scale, mask.shape[0] * scale), interpolation=cv2.INTER_CUBIC)
    mask = (mask > 127).astype(np.uint8) * 255
    mm_per_px = width_mm / mask.shape[1]
    k = max(1, int(round(min_feature_mm / mm_per_px / 2)))
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * k + 1, 2 * k + 1))
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)        # drop slivers thinner than the minimum feature
    contours, hier = cv2.findContours(mask, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
    out = []
    if hier is None:
        return out, mm_per_px, mask.shape
    hier = hier[0]
    for i, c in enumerate(contours):
        if hier[i][3] != -1:
            continue                                     # holes are handled with their parent
        if cv2.contourArea(c) * mm_per_px ** 2 < min_feature_mm ** 2 * 2:
            continue
        holes = []
        j = hier[i][2]
        while j != -1:
            if cv2.contourArea(contours[j]) * mm_per_px ** 2 >= min_feature_mm ** 2:
                holes.append(cv2.approxPolyDP(contours[j], 0.6, True)[:, 0, :])
            j = hier[j][0]
        out.append((cv2.approxPolyDP(c, 0.6, True)[:, 0, :], holes))
    return out, mm_per_px, mask.shape


def to_set(pts, cx, cy, mm_per_px, w, h, mirror=False):
    s = pcbnew.SHAPE_POLY_SET()
    s.NewOutline()
    for u, v in pts:
        x = (u - w / 2.0) * mm_per_px
        y = (v - h / 2.0) * mm_per_px
        if mirror:
            x = -x
        s.Append(pcbnew.FromMM(float(cx + x)), pcbnew.FromMM(float(cy + y)))
    return s


def add_logo(board, png, cx, cy, width_mm, layer='F.SilkS', invert=False, min_feature_mm=0.16):
    polys, mm_per_px, (h, w) = logo_polys(png, width_mm, min_feature_mm, invert)
    lid = board.GetLayerID(layer)
    if lid < 0:                         # fresh BOARD() objects only know the canonical layer constants
        lid = getattr(pcbnew, layer.replace(".", "_"))
    mirror = layer.startswith('B.')
    n = 0
    for outer, holes in polys:
        s = to_set(outer, cx, cy, mm_per_px, w, h, mirror)
        for hole in holes:
            s.BooleanSubtract(to_set(hole, cx, cy, mm_per_px, w, h, mirror))
        shape = pcbnew.PCB_SHAPE(board)
        shape.SetShape(pcbnew.SHAPE_T_POLY)
        shape.SetFilled(True)
        shape.SetWidth(0)
        shape.SetLayer(lid)
        shape.SetPolyShape(s)
        board.Add(shape)
        n += 1
    return n, (w * mm_per_px, h * mm_per_px)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('board')
    ap.add_argument('logo')
    ap.add_argument('--x', type=float, required=True)
    ap.add_argument('--y', type=float, required=True)
    ap.add_argument('--width', type=float, required=True)
    ap.add_argument('--layer', default='F.SilkS')
    ap.add_argument('--invert', action='store_true')
    ap.add_argument('--out')
    a = ap.parse_args()
    b = pcbnew.LoadBoard(a.board)
    n, size = add_logo(b, a.logo, a.x, a.y, a.width, a.layer, a.invert)
    pcbnew.SaveBoard(a.out or a.board, b)
    print('added %d polygons, logo %.2f x %.2f mm on %s' % (n, size[0], size[1], a.layer))
