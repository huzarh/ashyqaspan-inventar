# SPDX-License-Identifier: CERN-OHL-P-2.0
"""Surgical edits of KiCad 9 schematic files (placed symbols by reference) that preserve the original formatting."""
import re


def _block_end(s, start):
    depth, k = 0, start
    while True:
        c = s[k]
        if c == '"':
            k += 1
            while s[k] != '"':
                k += 2 if s[k] == '\\' else 1
        elif c == '(':
            depth += 1
        elif c == ')':
            depth -= 1
            if depth == 0:
                return k + 1
        k += 1


def placed_symbols(s):
    """Yield (start, end, reference) for every placed symbol (top-level '(symbol' with a lib_id)."""
    i = 0
    while True:
        j = s.find('\n\t(symbol\n\t\t(lib_id', i)
        if j < 0:
            return
        j += 2
        k = _block_end(s, j)
        m = re.search(r'\n\t\t\(property "Reference" "([^"]+)"', s[j:k])
        yield j, k, (m.group(1) if m else None)
        i = k


def edit_symbol(s, ref, props=None, dnp=None):
    """Set/add properties (hidden when new) and the DNP flag of the placed symbol `ref`. Returns the new text."""
    hits = [(a, b) for a, b, r in placed_symbols(s) if r == ref]
    if len(hits) != 1:
        raise ValueError('%s: %d placed symbols found' % (ref, len(hits)))
    a, b = hits[0]
    blk = s[a:b]
    for name, value in (props or {}).items():
        esc = value.replace('\\', '\\\\').replace('"', '\\"')
        m = re.search(r'\n\t\t\(property "%s" "((?:\\.|[^"\\])*)"' % re.escape(name), blk)
        if m:
            blk = blk[:m.start(1)] + esc + blk[m.end(1):]
            continue
        # place the new hidden field at the symbol position, after the last property
        at = re.search(r'\n\t\t\(at ([-\d.]+) ([-\d.]+)', blk)
        last = list(re.finditer(r'\n\t\t\(property ', blk))[-1]
        end = _block_end(blk, last.start() + 3)
        new = ('\n\t\t(property "%s" "%s"\n\t\t\t(at %s %s 0)\n\t\t\t(effects\n\t\t\t\t(font\n\t\t\t\t\t(size 1.27 1.27)\n'
               '\t\t\t\t)\n\t\t\t\t(hide yes)\n\t\t\t)\n\t\t)') % (name, esc, at.group(1), at.group(2))
        blk = blk[:end] + new + blk[end:]
    if dnp is not None:
        blk, n = re.subn(r'\n\t\t\(dnp (yes|no)\)', '\n\t\t(dnp %s)' % ('yes' if dnp else 'no'), blk, count=1)
        if n != 1:
            raise ValueError('%s: no dnp flag' % ref)
    return s[:a] + blk + s[b:]
