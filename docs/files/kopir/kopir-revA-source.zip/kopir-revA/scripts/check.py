#!/usr/bin/env python3
# SPDX-License-Identifier: CERN-OHL-P-2.0
"""Design check against the upstream baseline: ERC, DRC (+schematic parity), structural netlist diff, and (with
--upstream-pcb) copper geometry: every track, arc and via (ends, width, drill, via type and layer pair) and every pad
(position, orientation, layer set, drill, and the outline of its copper on each layer, which covers size, shape, corner
rounding and offset) compared with the upstream board, plus the pour clearances JLCPCB needs: KiCad's DRC does not
apply a zone-only edge-clearance rule to existing fills, so the GND fill is measured against the board edge and
cut-outs here (and, as a cross-check, against the unplated holes, which DRC does check).

    python3 scripts/check.py hardware/kopir-c3/kopir-c3 [--baseline baseline] [--upstream-pcb upstream.kicad_pcb] [--json out.json]
Exit code 1 if ERC/DRC error-level counts grew, a track/via/pad differs from upstream, or a pour is too close.
"""
import argparse
import collections
import json
import os
import re
import subprocess
import sys
import tempfile


def sexp(text):
    tokens = re.findall(r'\(|\)|"(?:\\.|[^"\\])*"|[^\s()"]+', text)
    stack, cur = [], []
    for t in tokens:
        if t == '(':
            stack.append(cur)
            cur = []
        elif t == ')':
            done = cur
            cur = stack.pop()
            cur.append(done)
        else:
            cur.append(t[1:-1].replace('\\"', '"') if t.startswith('"') else t)
    return cur[0]


def find(node, key):
    return [c for c in node if isinstance(c, list) and c and c[0] == key]


def val(node, key, default=''):
    f = find(node, key)
    return f[0][1] if f and len(f[0]) > 1 else default


def netlist(path):
    root = sexp(open(path, encoding='utf-8').read())
    comps = {}
    for c in find(find(root, 'components')[0], 'comp'):
        comps[val(c, 'ref')] = (val(c, 'value'), val(c, 'footprint'))
    nets = {}
    for n in find(find(root, 'nets')[0], 'net'):
        nodes = frozenset((val(x, 'ref'), val(x, 'pin')) for x in find(n, 'node'))
        nets[val(n, 'name')] = nodes
    return comps, nets


def counts(path, kind):
    d = json.load(open(path))
    items = []
    if kind == 'erc':
        for s in d.get('sheets', []):
            items += s.get('violations', [])
    else:
        items = d.get('violations', []) + d.get('unconnected_items', []) + d.get('schematic_parity', [])
    return collections.Counter((v.get('severity'), v.get('type')) for v in items), items


def copper(pcb, upstream):
    """Tracks, vias and pads compared with the upstream board (by geometry, not by name); pour clearances."""
    import pcbnew
    mm = lambda v: round(pcbnew.ToMM(v), 4)

    def geometry(path):
        b = pcbnew.LoadBoard(path)
        tracks = set()
        for t in b.GetTracks():
            key = (t.GetClass(), b.GetLayerName(t.GetLayer()), mm(t.GetStart().x), mm(t.GetStart().y), mm(t.GetEnd().x),
                   mm(t.GetEnd().y))
            if t.GetClass() == 'PCB_VIA':
                key += (mm(t.GetWidth(pcbnew.F_Cu)), mm(t.GetDrillValue()), int(t.GetViaType()),
                        b.GetLayerName(t.TopLayer()), b.GetLayerName(t.BottomLayer()))
            else:
                key += (mm(t.GetWidth()),)
                if t.GetClass() == 'PCB_ARC':
                    key += (mm(t.GetMid().x), mm(t.GetMid().y))
            tracks.add(key)
        pads = set()
        for f in b.GetFootprints():
            for p in f.Pads():
                key = (f.GetReference(), p.GetNumber(), mm(p.GetPosition().x), mm(p.GetPosition().y),
                       round(p.GetOrientationDegrees() % 360, 3), int(p.GetAttribute()), mm(p.GetDrillSize().x),
                       mm(p.GetDrillSize().y), int(p.GetDrillShape()), ' '.join(b.GetLayerName(l) for l in p.GetLayerSet().Seq()))
                for layer in (pcbnew.F_Cu, pcbnew.B_Cu):
                    if p.IsOnLayer(layer):            # copper outline: size, shape, rounding, chamfers, offset
                        poly = pcbnew.SHAPE_POLY_SET()
                        p.TransformShapeToPolygon(poly, layer, 0, pcbnew.FromMM(0.001), pcbnew.ERROR_INSIDE)
                        bb = poly.BBox()
                        key += (b.GetLayerName(layer), round(poly.Area() / 1e12, 4), mm(bb.GetX()), mm(bb.GetY()),
                                mm(bb.GetRight()), mm(bb.GetBottom()))
                pads.add(key)
        return b, tracks, pads

    b, tn, pn = geometry(pcb)
    _, tu, pu = geometry(upstream)
    edge = pcbnew.SHAPE_POLY_SET()
    b.GetBoardPolygonOutlines(edge)
    segs = [edge.Outline(0).CSegment(i) for i in range(edge.Outline(0).SegmentCount())]
    for h in range(edge.HoleCount(0)):
        hole = edge.Hole(0, h)
        segs += [hole.CSegment(i) for i in range(hole.SegmentCount())]
    npth = [(p.GetPosition(), p.GetDrillSize().x / 2) for f in b.GetFootprints() for p in f.Pads()
            if p.GetAttribute() == pcbnew.PAD_ATTRIB_NPTH]
    pours = []
    for z in b.Zones():
        if z.GetIsRuleArea():
            continue
        for layer in z.GetLayerSet().Seq():
            fill = z.GetFilledPolysList(layer)
            d_edge = d_hole = 1e9
            for pi in range(fill.OutlineCount()):
                for ring in [fill.Outline(pi)] + [fill.Hole(pi, k) for k in range(fill.HoleCount(pi))]:
                    for k in range(ring.PointCount()):
                        p = ring.CPoint(k)
                        d_edge = min([d_edge] + [pcbnew.ToMM(s.Distance(p)) for s in segs])
                        d_hole = min([d_hole] + [pcbnew.ToMM((p - c).EuclideanNorm() - r) for c, r in npth])
            pours.append(dict(net=z.GetNetname(), layer=b.GetLayerName(layer), edge_mm=round(d_edge, 3), npth_mm=round(d_hole, 3)))
    return dict(tracks_vias_changed=sorted(tn ^ tu)[:20], tracks_vias=len(tn), pads_changed=sorted(pn ^ pu)[:20], pads=len(pn),
                pours=pours, pours_too_close=[p for p in pours if p['edge_mm'] < 0.29 or p['npth_mm'] < 0.24])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('project')
    ap.add_argument('--baseline', default='baseline')
    ap.add_argument('--json')
    ap.add_argument('--upstream-pcb', help='upstream .kicad_pcb for the copper geometry comparison (needs pcbnew)')
    a = ap.parse_args()
    tmp = tempfile.mkdtemp()
    sch, pcb = a.project + '.kicad_sch', a.project + '.kicad_pcb'
    subprocess.run(['kicad-cli', 'sch', 'erc', '--severity-all', '--format', 'json', '-o', tmp + '/erc.json', sch], capture_output=True)
    subprocess.run(['kicad-cli', 'pcb', 'drc', '--schematic-parity', '--severity-all', '--format', 'json', '-o', tmp + '/drc.json', pcb], capture_output=True)
    subprocess.run(['kicad-cli', 'sch', 'export', 'netlist', '-o', tmp + '/net.net', sch], capture_output=True)
    report = {}
    worse = False
    for kind in ('erc', 'drc'):
        now, items = counts(tmp + '/%s.json' % kind, kind)
        base, _ = counts(os.path.join(a.baseline, '%s.json' % kind), kind)
        delta = {('%s/%s' % k): now[k] - base.get(k, 0) for k in set(now) | set(base) if now[k] != base.get(k, 0)}
        report[kind] = dict(total=sum(now.values()), baseline_total=sum(base.values()), changed_types=delta,
                            new_items=[dict(type=v['type'], severity=v['severity'], desc=v.get('description', ''),
                                            items=[i.get('description', '') for i in v.get('items', [])][:3])
                                       for v in items if now[(v['severity'], v['type'])] > base.get((v['severity'], v['type']), 0)][:40])
        if any(k.startswith('error/') and v > 0 for k, v in delta.items()):
            worse = True
    bc, bn = netlist(os.path.join(a.baseline, 'netlist.net'))
    nc, nn = netlist(tmp + '/net.net')
    comp_added = sorted(set(nc) - set(bc))
    comp_removed = sorted(set(bc) - set(nc))
    comp_changed = sorted(r for r in set(bc) & set(nc) if bc[r] != nc[r])
    # nets are compared by connection sets, so renamed-but-identical nets are not reported as changes
    base_sets = {v: k for k, v in bn.items()}
    net_changes = []
    for name, nodes in nn.items():
        if nodes in base_sets:
            continue
        old = bn.get(name)
        if old is None:
            net_changes.append(dict(net=name, change='new', nodes=sorted('%s.%s' % x for x in nodes)))
        else:
            net_changes.append(dict(net=name, change='modified', added=sorted('%s.%s' % x for x in nodes - old),
                                    removed=sorted('%s.%s' % x for x in old - nodes)))
    for name, nodes in bn.items():
        if name not in nn and nodes not in set(nn.values()):
            net_changes.append(dict(net=name, change='gone', nodes=sorted('%s.%s' % x for x in nodes)))
    report['netlist'] = dict(components=len(nc), baseline_components=len(bc), added=comp_added, removed=comp_removed,
                             changed={r: [bc[r], nc[r]] for r in comp_changed}, net_changes=net_changes)
    if a.upstream_pcb:
        report['copper'] = copper(pcb, a.upstream_pcb)
        c = report['copper']
        if c['tracks_vias_changed'] or c['pads_changed'] or c['pours_too_close']:
            worse = True
    if a.json:
        json.dump(report, open(a.json, 'w'), indent=1)
    print(json.dumps(report, indent=1, ensure_ascii=False)[:12000])
    sys.exit(1 if worse else 0)


if __name__ == '__main__':
    main()
