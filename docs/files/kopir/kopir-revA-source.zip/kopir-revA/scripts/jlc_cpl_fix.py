#!/usr/bin/env python3
# SPDX-License-Identifier: CERN-OHL-P-2.0
"""JLCPCB placement file (CPL) with rotation and centre corrections taken from the LCSC parts' own footprints.

For every assembled footprint (LCSC field set, not DNP, not excluded from BOM/position files) the LCSC part's EasyEDA
footprint is fetched (cached), and the rotation (0/90/180/270) plus origin offset that maps its pads onto the KiCad
footprint's pads is solved - by pad number when both use the same numbering, otherwise by pure pad geometry. The CPL
then carries the rotation and centre that JLCPCB's library expects, instead of KiCad's own footprint convention.
Next to every pad the EasyEDA symbol pin name and the KiCad net are reported, so polarity can be checked by eye.

    python3 jlc_cpl_fix.py board.kicad_pcb --out board_cpl_jlc.csv --report board_cpl_report.json
"""
import argparse
import csv
import json
import math
import os
import re
import sys
import time

import pcbnew
from easyeda2kicad.easyeda.easyeda_api import EasyedaApi
from easyeda2kicad.easyeda.easyeda_importer import EasyedaFootprintImporter, EasyedaSymbolImporter

CACHE = os.path.expanduser('~/pcb/.cache/easyeda')


def rot(p, deg):
    """KiCad RotatePoint convention: y points down, positive angles turn counter-clockwise on screen."""
    a = math.radians(deg)
    c, s = math.cos(a), math.sin(a)
    return (p[0] * c + p[1] * s, -p[0] * s + p[1] * c)


def cad_data(lcsc):
    os.makedirs(CACHE, exist_ok=True)
    path = os.path.join(CACHE, lcsc + '.json')
    if os.path.exists(path):
        return json.load(open(path))
    data = None
    for attempt in range(8):                     # the workshop uplink drops connections now and then
        data = EasyedaApi().get_cad_data_of_component(lcsc_id=lcsc)
        if data:
            break
        time.sleep(2 + 2 * attempt)
    if not data:
        raise RuntimeError('no EasyEDA data for ' + lcsc)
    json.dump(data, open(path, 'w'))
    return data


def easyeda_part(lcsc):
    data = cad_data(lcsc)
    fp = EasyedaFootprintImporter(easyeda_cp_cad_data=data).get_footprint()
    pads = [(str(p.number), (p.center_x - fp.bbox.x, p.center_y - fp.bbox.y)) for p in fp.pads]
    names = {}
    try:
        sym = EasyedaSymbolImporter(easyeda_cp_cad_data=data).get_symbol()
        for pin in sym.pins:
            names[str(pin.settings.spice_pin_number)] = pin.name.text
    except Exception as e:                       # symbol parsing is only used for the polarity report
        names['?'] = 'symbol not parsed: %s' % e
    return dict(package=fp.info.name, pads=pads, names=names, title=data.get('title', ''))


SYNONYMS = {'VSS': 'GND', 'VCC': 'VDD', 'CATHODE': 'K', 'C': 'K', '-': 'K', 'ANODE': 'A', '+': 'A', 'DI': 'DIN', 'DO': 'DOUT',
            'GATE': 'G', 'SOURCE': 'S', 'DRAIN': 'D', 'DP1': 'D+', 'DN1': 'D-', 'DP2': 'D+', 'DN2': 'D-',
            'U0RXD': 'RXD0', 'U0TXD': 'TXD0'}


def norm(name):
    """Comparable pin function name ('MECH' for shield/mounting pads), or None for unnamed / purely numeric pins."""
    if not name:
        return None
    n = name.strip().upper().split('/')[0]          # 'GPIO0/ADC1_CH0/XTAL_32K_P' -> 'GPIO0'
    if n in ('~', '') or n.isdigit():
        return None
    n = re.sub(r'_\d+$', '', n)                      # 'RESV_3' -> 'RESV'
    m = re.match(r'^GPIO(\d+)$', n)
    if m:
        n = 'IO' + m.group(1)
    if n in ('EH', 'MP', 'EP', 'PAD', 'MH', 'SHIELD') or n.startswith('SHELL'):
        return 'MECH'
    return SYNONYMS.get(n, n)


def same_function(a, b):
    """True when two pin names share any alias ('GPIO20/U0RXD' ~ 'RXD0'); 'A' vs 'K' stays a clash."""
    ta = {norm(t) for t in a.split('/')} - {None}
    tb = {norm(t) for t in b.split('/')} - {None}
    return bool(ta & tb) or 'MECH' in ta or 'MECH' in tb


def centroids(pairs):
    acc = {}
    for n, (x, y) in pairs:
        acc.setdefault(n, []).append((x, y))
    return {n: (sum(x for x, _ in v) / len(v), sum(y for _, y in v) / len(v)) for n, v in acc.items() if n}


def bbox_centre(points):
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    return (min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2


def fit(pairs, deg):
    """Translation and RMS residual for rot(easyeda, deg) + t ~ kicad over (kicad_xy, easyeda_xy) pairs.

    The translation aligns the bounding-box centres of the paired pad centres (LCSC footprints have their origin
    there); a least-squares mean would drift whenever the two libraries space the pads differently."""
    rp = [(k, rot(e, deg)) for k, e in pairs]
    kcx, kcy = bbox_centre([k for k, _ in rp])
    ecx, ecy = bbox_centre([r for _, r in rp])
    tx, ty = kcx - ecx, kcy - ecy
    res = math.sqrt(sum((k[0] - r[0] - tx) ** 2 + (k[1] - r[1] - ty) ** 2 for k, r in rp) / len(rp))
    return tx, ty, res


def solve(kpads, epads, kfunc, enames, kcopper=None):
    """Best rotation/offset mapping the EasyEDA footprint onto the KiCad one (KiCad frame at 0 deg).

    Pads are paired by pin function when both sides name their pins (this is what keeps diodes and LEDs the right way
    round even when the two libraries number the pads differently), else by pad number, else by geometry alone."""
    kc, ec = centroids(kpads), centroids(epads)
    kf = {}
    for n, f in kfunc.items():
        if norm(f):
            kf.setdefault(norm(f), []).append(n)
    ef = {}
    for n, f in enames.items():
        if norm(f) and n in ec:
            ef.setdefault(norm(f), []).append(n)
    fpairs = [(kc[kf[f][0]], ec[ef[f][0]]) for f in kf
              if f in ef and f != 'MECH' and len(kf[f]) == 1 and len(ef[f]) == 1 and kf[f][0] in kc]
    kcount, ecount = {}, {}
    for n, _ in kpads:
        kcount[n] = kcount.get(n, 0) + 1
    for n, _ in epads:
        ecount[n] = ecount.get(n, 0) + 1
    common = [n for n in sorted(set(kc) & set(ec)) if kcount[n] == ecount[n]]
    if len(fpairs) >= 2:
        mode, pairs = 'pin functions (%d)' % len(fpairs), fpairs
    elif len(common) >= 2 and len(common) == len(set(kc) & set(ec)):
        mode, pairs = 'pad numbers (%d)' % len(common), [(kc[n], ec[n]) for n in common]
    else:
        mode, pairs = 'geometry', None
    results = []
    kp = [p for _, p in kpads]
    for deg in (0, 90, 180, 270):
        if pairs:
            tx, ty, res = fit(pairs, deg)
        else:                                    # align centroids of all pads, nearest-neighbour residual
            ep = [rot(p, deg) for _, p in epads]
            (kcx, kcy), (ecx, ecy) = bbox_centre(kp), bbox_centre(ep)
            tx, ty = kcx - ecx, kcy - ecy
            res = math.sqrt(sum(min((x + tx - a) ** 2 + (y + ty - b) ** 2 for a, b in kp) for x, y in ep) / len(ep))
        landed = []                              # where every EasyEDA pad lands: nearest KiCad pad and distance
        for en, p in epads:
            q = rot(p, deg)
            kn, d = min(((n, math.hypot(q[0] + tx - a, q[1] + ty - b)) for n, (a, b) in kpads), key=lambda t: t[1])
            landed.append((en, kn, d))
        worst = max(d for _, _, d in landed)
        placed = [(rot(p, deg)[0] + tx, rot(p, deg)[1] + ty) for _, p in epads]
        uncovered = sorted({n for n, (a, b) in kpads if (kcopper is None or kcopper.get(n, True))
                            and min(math.hypot(a - x, b - y) for x, y in placed) > 0.5})
        clash = sorted({'%s(%s)->%s(%s)' % (en, enames.get(en), kn, kfunc.get(kn)) for en, kn, d in landed
                        if d < 0.5 and norm(enames.get(en)) not in (None, 'MECH') and norm(kfunc.get(kn)) not in (None, 'MECH')
                        and not same_function(enames[en], kfunc[kn])})
        results.append(dict(deg=deg, tx=round(tx, 4), ty=round(ty, 4), residual=round(res, 4), worst_pad=round(worst, 4), mode=mode,
                            function_clashes=clash, uncovered_kicad_pads=uncovered,
                            landing=[dict(lcsc_pad=en, lcsc_pin=enames.get(en), kicad_pad=kn, kicad_pin=kfunc.get(kn), distance_mm=round(d, 3))
                                     for en, kn, d in landed]))
    results.sort(key=lambda r: (r['residual'], r['worst_pad'], len(r['function_clashes']), len(r['uncovered_kicad_pads']), r['deg']))
    best = results[0]
    best['ambiguous_with'] = [r['deg'] for r in results[1:] if abs(r['residual'] - best['residual']) < 0.02
                              and abs(r['worst_pad'] - best['worst_pad']) < 0.05]
    best['compatible'] = (best['residual'] < 0.3 and best['worst_pad'] < 0.5 and not best['function_clashes']
                          and not best['uncovered_kicad_pads'])
    return best


def polarized(ref, package):
    """Parts whose orientation matters electrically; bidirectional protection diodes ('-BI' packages) excepted."""
    return ref[:1] in ('D', 'Q', 'U') and '-BI' not in package.upper()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('pcb')
    ap.add_argument('--out', required=True)
    ap.add_argument('--report')
    ap.add_argument('--field', default='LCSC')
    a = ap.parse_args()
    board = pcbnew.LoadBoard(a.pcb)
    rows, report, cache, bad = [], [], {}, []
    for fp in sorted(board.GetFootprints(), key=lambda f: f.GetReference()):
        ref = fp.GetReference()
        f = fp.GetFieldByName(a.field)
        lcsc = f.GetText().strip() if f else ''
        if not lcsc or fp.IsDNP() or fp.IsExcludedFromBOM() or fp.IsExcludedFromPosFiles():
            continue
        if fp.GetLayer() != pcbnew.F_Cu:
            sys.exit('%s is on the bottom side; this tool handles top-side assembly only' % ref)
        pos, ang = fp.GetPosition(), fp.GetOrientationDegrees()
        kpads, kfunc, kcopper = [], {}, {}
        for pad in fp.Pads():
            c = pad.GetPosition()
            kpads.append((pad.GetNumber(), rot((pcbnew.ToMM(c.x - pos.x), pcbnew.ToMM(c.y - pos.y)), -ang)))
            kcopper[pad.GetNumber()] = pad.GetAttribute() != pcbnew.PAD_ATTRIB_NPTH and pad.IsOnCopperLayer()
            if pad.GetPinFunction():
                kfunc[pad.GetNumber()] = pad.GetPinFunction()
        if lcsc not in cache:
            cache[lcsc] = easyeda_part(lcsc)
        part = cache[lcsc]
        sol = solve(kpads, part['pads'], kfunc, part['names'], kcopper)
        if polarized(ref, part['package']) and (not sol['mode'].startswith('pin functions') or sol['ambiguous_with']):
            sol['compatible'] = False                # orientation of a polarized part must be proven by pin names
            sol['function_clashes'] = sol['function_clashes'] + ['polarity not provable (%s%s)' % (
                sol['mode'], ', ambiguous with %s' % sol['ambiguous_with'] if sol['ambiguous_with'] else '')]
        off = rot((sol['tx'], sol['ty']), ang)
        x, y = pcbnew.ToMM(pos.x) + off[0], pcbnew.ToMM(pos.y) + off[1]
        jrot = (ang + sol['deg']) % 360
        rows.append({'Designator': ref, 'Mid X': '%.4f' % x, 'Mid Y': '%.4f' % -y, 'Layer': 'Top', 'Rotation': '%g' % jrot})
        nets = {p.GetNumber(): p.GetNetname() for p in fp.Pads()}
        for row in sol['landing']:                   # which LCSC pin lands on which KiCad pad (and net)
            row['kicad_net'] = nets.get(row['kicad_pad'])
        report.append(dict(ref=ref, lcsc=lcsc, kicad_footprint=fp.GetFPIDAsString(), easyeda_package=part['package'], title=part['title'],
                           kicad_rot=round(ang, 3), jlc_rot=round(jrot, 3), offset_deg=sol['deg'], centre_shift_mm=[round(off[0], 3), round(off[1], 3)],
                           residual_mm=sol['residual'], worst_pad_mm=sol['worst_pad'], mode=sol['mode'], ambiguous_with=sol['ambiguous_with'],
                           compatible=sol['compatible'], function_clashes=sol['function_clashes'],
                           uncovered_kicad_pads=sol['uncovered_kicad_pads'], landing=sol['landing']))
        bad.extend([] if sol['compatible'] else [ref])
        flag = '' if sol['compatible'] else '  <-- INCOMPATIBLE %s %s' % (' '.join(sol['function_clashes']),
                                                                          'uncovered KiCad pads %s' % sol['uncovered_kicad_pads'] if sol['uncovered_kicad_pads'] else '')
        print('%-5s %-10s %-34s %-28s rot %5.1f -> %5.1f (+%3d)  shift (%+.3f, %+.3f)  res %.3f worst %.3f  %s%s%s'
              % (ref, lcsc, fp.GetFPIDAsString().split(':')[-1][:34], part['package'][:28], ang, jrot, sol['deg'], off[0], off[1],
                 sol['residual'], sol['worst_pad'], sol['mode'], ' ambiguous:%s' % sol['ambiguous_with'] if sol['ambiguous_with'] else '', flag))
    with open(a.out, 'w', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=['Designator', 'Mid X', 'Mid Y', 'Layer', 'Rotation'])
        w.writeheader()
        w.writerows(rows)
    if a.report:
        json.dump(report, open(a.report, 'w'), indent=1, ensure_ascii=False)
    print('%d placements written to %s' % (len(rows), a.out))
    if bad:
        sys.exit('footprint/pinout mismatch with the LCSC part for: ' + ', '.join(bad))


if __name__ == '__main__':
    main()
